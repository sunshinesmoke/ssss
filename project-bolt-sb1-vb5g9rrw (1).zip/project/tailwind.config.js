/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        herb: {
          light: '#8BC34A',
          DEFAULT: '#4CAF50',
          dark: '#2E7D32',
        },
        smoke: {
          light: '#ECEFF1',
          DEFAULT: '#B0BEC5',
          dark: '#455A64',
        }
      },
      spacing: {
        '70': '280px',
      },
      backgroundImage: {
        'leaf-pattern': "url('https://www.transparenttextures.com/patterns/leaves.png')",
      },
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
  ],
}