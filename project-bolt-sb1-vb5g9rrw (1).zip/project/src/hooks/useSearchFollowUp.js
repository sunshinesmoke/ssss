import { useState, useEffect } from 'react';

export default function useSearchFollowUp() {
  const [showFollowUp, setShowFollowUp] = useState(false);
  const [lastSearchTerm, setLastSearchTerm] = useState('');
  const [searchTimeout, setSearchTimeout] = useState(null);

  const handleSearch = (searchTerm) => {
    setLastSearchTerm(searchTerm);
    
    // Clear existing timeout
    if (searchTimeout) {
      clearTimeout(searchTimeout);
    }

    // Set new timeout for follow-up
    if (searchTerm) {
      const timeout = setTimeout(() => {
        // Show follow-up if user hasn't purchased
        const hasRecentPurchase = false; // You can implement actual purchase check logic
        if (!hasRecentPurchase) {
          setShowFollowUp(true);
        }
      }, 30000); // Show after 30 seconds of inactivity

      setSearchTimeout(timeout);
    }
  };

  // Clean up timeout on unmount
  useEffect(() => {
    return () => {
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }
    };
  }, [searchTimeout]);

  return {
    showFollowUp,
    setShowFollowUp,
    lastSearchTerm,
    handleSearch
  };
}