import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import { Toaster } from 'react-hot-toast';
import Layout from './components/Layout';
import Home from './pages/Home';
import About from './pages/About';
import Contact from './pages/Contact';
import Quiz from './pages/Quiz';
import Blog from './pages/Blog';
import BlogPost from './pages/BlogPost';
import Auth from './pages/Auth';
import ReturnPolicy from './pages/ReturnPolicy';
import Privacy from './pages/Privacy';
import ThcaVsThc from './pages/ThcaVsThc';
import LabReportGuide from './pages/LabReportGuide';
import VapeGuide from './pages/VapeGuide';
import Careers from './pages/Careers';
import Cigars from './pages/Cigars';
import Rewards from './pages/Rewards';
import Products from './pages/Products';
import Categories from './pages/Categories';
import ProductQuiz from './pages/ProductQuiz';
import ThcaFlower from './pages/ThcaFlower';
import Edibles from './pages/Edibles';
import NicotineDisposables from './pages/NicotineDisposables';
import ChocolateCookies from './pages/Products/ChocolateCookies';
import AgeGate from './components/AgeGate';

export default function App() {
  const [isAgeGateOpen, setIsAgeGateOpen] = React.useState(false);

  React.useEffect(() => {
    const isVerified = localStorage.getItem('age-verified');
    if (!isVerified) {
      setIsAgeGateOpen(true);
    }
  }, []);

  const handleAgeVerification = () => {
    setIsAgeGateOpen(false);
  };

  return (
    <HelmetProvider>
      <Router>
        <AgeGate isOpen={isAgeGateOpen} onVerify={handleAgeVerification} />
        <Layout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/quiz" element={<Quiz />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/blog/ultimate-smoke-shop-guide" element={<BlogPost />} />
            <Route path="/login" element={<Auth />} />
            <Route path="/register" element={<Auth />} />
            <Route path="/return-policy" element={<ReturnPolicy />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/thca-vs-thc" element={<ThcaVsThc />} />
            <Route path="/lab-report-guide" element={<LabReportGuide />} />
            <Route path="/vape-guide" element={<VapeGuide />} />
            <Route path="/careers" element={<Careers />} />
            <Route path="/cigars" element={<Cigars />} />
            <Route path="/rewards" element={<Rewards />} />
            <Route path="/products" element={<Products />} />
            <Route path="/categories" element={<Categories />} />
            <Route path="/product-quiz" element={<ProductQuiz />} />
            <Route path="/thca-flower" element={<ThcaFlower />} />
            <Route path="/edibles" element={<Edibles />} />
            <Route path="/nicotine-disposables" element={<NicotineDisposables />} />
            <Route path="/products/magic-chocolate-cookies" element={<ChocolateCookies />} />
          </Routes>
        </Layout>
        <Toaster position="bottom-right" />
      </Router>
    </HelmetProvider>
  );
}