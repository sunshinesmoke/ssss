import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';

const mainLinks = [
  { name: 'Home', path: '/', icon: '🏠' },
  { name: 'Products', path: '/products', icon: '🛍️' },
  { name: 'Categories', path: '/categories', icon: '📑' },
  { name: 'Quiz', path: '/quiz', icon: '❓' },
  { name: 'Blog', path: '/blog', icon: '📝' }
];

const productLinks = [
  { name: 'THCA Flower', path: '/thca-flower', icon: '🌿' },
  { name: 'Vapes', path: '/nicotine-disposables', icon: '💨' },
  { name: 'Edibles', path: '/edibles', icon: '🍬' },
  { name: 'Cigars', path: '/cigars', icon: '🌴' }
];

const infoLinks = [
  { name: 'About', path: '/about', icon: 'ℹ️' },
  { name: 'Contact', path: '/contact', icon: '📞' },
  { name: 'Careers', path: '/careers', icon: '💼' }
];

export default function Sidebar({ isOpen, onClose }) {
  const location = useLocation();

  const isActive = (path) => location.pathname === path;

  const LinkGroup = ({ title, links }) => (
    <div className="mb-8">
      <h3 className="text-gray-400 text-sm font-medium mb-4 px-4">{title}</h3>
      <div className="space-y-2">
        {links.map((link) => (
          <Link
            key={link.path}
            to={link.path}
            className={`flex items-center px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              isActive(link.path)
                ? 'bg-herb text-white'
                : 'text-gray-600 hover:bg-herb-light hover:bg-opacity-10 hover:text-herb'
            }`}
          >
            <span className="mr-3">{link.icon}</span>
            {link.name}
          </Link>
        ))}
      </div>
    </div>
  );

  return (
    <motion.div
      initial={{ x: -280 }}
      animate={{ x: isOpen ? 0 : -280 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
      className="fixed top-0 left-0 h-full w-70 bg-white border-r border-gray-200 z-40 overflow-y-auto"
    >
      <div className="p-6">
        <Link to="/" className="flex items-center space-x-2 mb-8">
          <span className="text-2xl">☀️</span>
          <span className="text-xl font-bold text-gray-900">Sunshine Smoke</span>
        </Link>

        <LinkGroup title="Main Menu" links={mainLinks} />
        <LinkGroup title="Products" links={productLinks} />
        <LinkGroup title="Information" links={infoLinks} />

        <div className="mt-8 p-4 bg-herb-light bg-opacity-10 rounded-lg">
          <p className="text-sm text-gray-600 mb-2">Need help?</p>
          <a
            href="tel:4077781326"
            className="flex items-center text-herb hover:text-herb-dark transition-colors"
          >
            <span className="mr-2">📞</span>
            (407) 778-1326
          </a>
        </div>
      </div>
    </motion.div>
  );
}