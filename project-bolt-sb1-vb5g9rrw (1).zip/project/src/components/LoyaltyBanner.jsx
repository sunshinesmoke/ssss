import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

export default function LoyaltyBanner() {
  return (
    <motion.div 
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-r from-herb-dark to-herb relative overflow-hidden"
    >
      <div className="absolute inset-0 bg-leaf-pattern opacity-10"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 relative">
        <div className="flex items-center justify-between flex-wrap">
          <div className="w-0 flex-1 flex items-center">
            <span className="flex p-2 rounded-lg bg-herb-light bg-opacity-10">
              <span className="text-xl">⭐</span>
            </span>
            <p className="ml-3 font-medium text-white truncate">
              <span className="md:hidden">Join VIP Rewards!</span>
              <span className="hidden md:inline">Join Sunshine Smoke VIP Rewards - Get 10% off every order!</span>
            </p>
          </div>
          <div className="order-3 mt-2 flex-shrink-0 w-full sm:order-2 sm:mt-0 sm:w-auto">
            <Link
              to="/rewards"
              className="flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-herb-dark bg-white hover:bg-gray-50"
            >
              Join Now
            </Link>
          </div>
        </div>
      </div>
    </motion.div>
  );
}