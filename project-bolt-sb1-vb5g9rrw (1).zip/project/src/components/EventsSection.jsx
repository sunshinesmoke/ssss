import React from 'react';
import { motion } from 'framer-motion';

const upcomingEvents = [
  {
    id: 1,
    title: "Rolling Masterclass",
    date: "Every Thursday",
    time: "7:00 PM",
    description: "Learn expert rolling techniques from our pros.",
    location: "World Center Drive Location"
  },
  {
    id: 2,
    title: "New Product Showcase",
    date: "First Friday Monthly",
    time: "4:20 PM",
    description: "Be the first to try our latest THCA products.",
    location: "All Locations"
  },
  {
    id: 3,
    title: "VIP Member Night",
    date: "Last Saturday Monthly",
    time: "6:00 PM",
    description: "Exclusive deals and tastings for VIP members.",
    location: "Sand Lake Location"
  }
];

export default function EventsSection() {
  return (
    <div className="bg-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900">Upcoming Events</h2>
          <p className="mt-4 text-lg text-gray-600">
            Join us for exclusive events and educational sessions
          </p>
        </div>

        <div className="mt-12 grid gap-8 md:grid-cols-3">
          {upcomingEvents.map((event, index) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-herb-light bg-opacity-5 rounded-lg p-6 hover:shadow-lg transition-shadow"
            >
              <div className="text-2xl mb-4">🎉</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{event.title}</h3>
              <div className="text-herb-dark font-medium mb-2">{event.date} at {event.time}</div>
              <p className="text-gray-600 mb-4">{event.description}</p>
              <div className="text-sm text-gray-500">{event.location}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}