import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

const locations = [
  {
    id: 1,
    name: "Sunshine Smoke Shop - World Center",
    address: "8216 World Center Drive, Suite D",
    city: "Orlando",
    state: "FL",
    zip: "32821",
    phone: "(407) 778-1326",
    hours: "Open 24/7",
    coords: {
      lat: 28.3894,
      lng: -81.4798
    }
  },
  {
    id: 2,
    name: "Sunshine Smoke Shop - Sand Lake",
    address: "6203 W Sand Lake Rd, Suite C",
    city: "Orlando",
    state: "FL",
    zip: "32819",
    phone: "(321) 440-4191",
    hours: "9:00 AM - 2:00 AM Daily",
    coords: {
      lat: 28.4502,
      lng: -81.4759
    }
  },
  {
    id: 3,
    name: "Sunshine Smoke Shop - Vineland",
    address: "5661 Vineland Rd",
    city: "Orlando",
    state: "FL",
    zip: "32819",
    phone: "(321) 440-4191",
    hours: "9:00 AM - 2:00 AM Daily",
    coords: {
      lat: 28.4849,
      lng: -81.4589
    }
  },
  {
    id: 4,
    name: "Sunshine Smoke Shop - Kissimmee 192",
    address: "5192 W Irlo Bronson Memorial Hwy",
    city: "Kissimmee",
    state: "FL",
    zip: "34746",
    phone: "(321) 440-4191",
    hours: "Open 24/7",
    coords: {
      lat: 28.3317,
      lng: -81.4592
    }
  },
  {
    id: 5,
    name: "Sunshine Smoke Shop - Kissimmee 27",
    address: "7726 W Irlo Bronson Memorial Hwy",
    city: "Kissimmee",
    state: "FL",
    zip: "34747",
    phone: "(321) 440-4191",
    hours: "9:00 AM - 2:00 AM Daily",
    coords: {
      lat: 28.3338,
      lng: -81.6362
    }
  }
];

export default function NearestLocation() {
  const [userLocation, setUserLocation] = useState(null);
  const [nearestStore, setNearestStore] = useState(null);
  const [locationError, setLocationError] = useState(null);
  const [loading, setLoading] = useState(true);

  // Calculate distance between two points using Haversine formula
  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371; // Earth's radius in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c;
    return distance * 0.621371; // Convert to miles
  };

  // Find nearest store based on user's location
  const findNearestStore = (userLat, userLng) => {
    let nearest = null;
    let shortestDistance = Infinity;

    locations.forEach(store => {
      const distance = calculateDistance(
        userLat,
        userLng,
        store.coords.lat,
        store.coords.lng
      );

      if (distance < shortestDistance) {
        shortestDistance = distance;
        nearest = { ...store, distance };
      }
    });

    return nearest;
  };

  useEffect(() => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setUserLocation({ lat: latitude, lng: longitude });
          const nearest = findNearestStore(latitude, longitude);
          setNearestStore(nearest);
          setLoading(false);
        },
        (error) => {
          console.error('Error getting location:', error);
          setLocationError('Unable to get your location. Showing all stores.');
          setLoading(false);
        }
      );
    } else {
      setLocationError('Geolocation is not supported by your browser. Showing all stores.');
      setLoading(false);
    }
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      {locationError ? (
        <div className="p-4 bg-yellow-50 border-l-4 border-yellow-400 text-yellow-700">
          <p>{locationError}</p>
        </div>
      ) : nearestStore && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-6"
        >
          <div className="flex items-start justify-between">
            <div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                Your Nearest Store
              </h3>
              <p className="text-green-600 font-medium mb-4">
                {nearestStore.distance.toFixed(1)} miles away
              </p>
            </div>
            <a
              href={`https://www.google.com/maps/dir/?api=1&destination=${nearestStore.coords.lat},${nearestStore.coords.lng}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
            >
              Get Directions
            </a>
          </div>

          <div className="mt-4">
            <h4 className="font-semibold text-gray-900">{nearestStore.name}</h4>
            <p className="text-gray-600 mt-1">{nearestStore.address}</p>
            <p className="text-gray-600">{nearestStore.city}, {nearestStore.state} {nearestStore.zip}</p>
            <p className="text-gray-800 font-medium mt-2">{nearestStore.hours}</p>
            <a
              href={`tel:${nearestStore.phone.replace(/[^0-9]/g, '')}`}
              className="inline-block mt-2 text-primary-600 hover:text-primary-800"
            >
              {nearestStore.phone}
            </a>
          </div>

          <div className="mt-6 pt-6 border-t border-gray-200">
            <h4 className="font-medium text-gray-900 mb-2">Store Features:</h4>
            <ul className="grid grid-cols-2 gap-4">
              <li className="flex items-center text-gray-600">
                <span className="text-green-500 mr-2">✓</span>
                Premium THCA Products
              </li>
              <li className="flex items-center text-gray-600">
                <span className="text-green-500 mr-2">✓</span>
                Vape Selection
              </li>
              <li className="flex items-center text-gray-600">
                <span className="text-green-500 mr-2">✓</span>
                Glass & Accessories
              </li>
              <li className="flex items-center text-gray-600">
                <span className="text-green-500 mr-2">✓</span>
                Expert Staff
              </li>
            </ul>
          </div>
        </motion.div>
      )}
    </div>
  );
}