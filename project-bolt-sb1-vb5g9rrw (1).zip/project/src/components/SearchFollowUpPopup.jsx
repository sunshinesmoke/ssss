import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { XMarkIcon } from '@heroicons/react/24/outline';
import { Link } from 'react-router-dom';

export default function SearchFollowUpPopup({ isOpen, onClose, searchTerm, nearestLocation }) {
  const promoCode = 'SUNSHINE20';

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
      >
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-herb to-herb-dark p-6 text-white relative">
            <button
              onClick={onClose}
              className="absolute top-4 right-4 text-white hover:text-gray-200 transition-colors"
            >
              <XMarkIcon className="h-6 w-6" />
            </button>
            <h2 className="text-2xl font-bold mb-2">Thanks for Visiting! 🌟</h2>
            <p className="text-herb-light">We noticed you were looking for "{searchTerm}"</p>
          </div>

          {/* Content */}
          <div className="p-6 space-y-6">
            {/* Nearest Location */}
            <div className="bg-herb-light bg-opacity-10 rounded-lg p-4">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Your Nearest Store 📍</h3>
              <div className="space-y-2">
                <p className="font-medium text-gray-900">{nearestLocation.name}</p>
                <p className="text-gray-600">{nearestLocation.address}</p>
                <p className="text-gray-600">{nearestLocation.hours}</p>
                <p className="text-herb font-medium">{nearestLocation.phone}</p>
              </div>
            </div>

            {/* Instagram Promo */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Follow Us & Save! 📸</h3>
              <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-2xl">Instagram</span>
                  <span className="text-xl">@sunshinesmokeshop</span>
                </div>
                <p className="text-sm mb-3">
                  Follow us on Instagram for exclusive deals, new products, and behind-the-scenes content!
                </p>
                <a
                  href="https://www.instagram.com/sunshinesmokeshop"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full bg-white text-pink-500 text-center py-2 rounded-lg font-medium hover:bg-gray-100 transition-colors"
                >
                  Follow & Get 20% OFF
                </a>
              </div>
            </div>

            {/* Promo Code */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Special First-Order Offer! 🎉</h3>
              <div className="bg-yellow-50 border-2 border-dashed border-yellow-200 rounded-lg p-4 text-center">
                <p className="text-gray-700 mb-2">Use code:</p>
                <p className="text-2xl font-bold text-herb-dark mb-2">{promoCode}</p>
                <p className="text-sm text-gray-600">Get 20% off your first purchase!</p>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="space-y-3">
              <Link
                to="/products"
                className="block w-full bg-herb text-white text-center py-3 px-4 rounded-lg hover:bg-herb-dark transition-colors"
              >
                Continue Shopping
              </Link>
              <a
                href={`https://maps.google.com/?q=${encodeURIComponent(
                  `${nearestLocation.address}, ${nearestLocation.city}, FL`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="block w-full bg-gray-100 text-gray-700 text-center py-3 px-4 rounded-lg hover:bg-gray-200 transition-colors"
              >
                Get Directions
              </a>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}