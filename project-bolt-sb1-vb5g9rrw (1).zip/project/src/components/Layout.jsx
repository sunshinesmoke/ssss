import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Sidebar from './Sidebar';
import LoyaltyBanner from './LoyaltyBanner';
import Chat from './Chat';
import { Bars3Icon } from '@heroicons/react/24/outline';

export default function Layout({ children }) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />
      
      <div className={`transition-all duration-300 ${isSidebarOpen ? 'ml-70' : 'ml-0'}`}>
        <div className="sticky top-0 z-30 bg-white border-b border-gray-200">
          <div className="flex items-center px-4 py-3">
            <button
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 rounded-lg text-gray-600 hover:bg-gray-100 transition-colors"
            >
              <Bars3Icon className="h-6 w-6" />
            </button>
          </div>
          <LoyaltyBanner />
        </div>

        <main className="p-6">
          {children}
        </main>
      </div>

      <Chat />
    </div>
  );
}