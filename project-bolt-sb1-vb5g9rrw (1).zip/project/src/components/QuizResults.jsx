import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

export default function QuizResults({ answers, onStartOver }) {
  const getRecommendations = () => {
    // Example recommendations based on answers
    return {
      products: [
        {
          name: "Premium THCA Flower",
          description: "Indoor-grown, lab-tested THCA flower with exceptional terpene profile.",
          price: 39.99,
          rating: 4.8,
          reviews: 156,
          link: "/thca-flower"
        },
        {
          name: "Delta-8 Disposable Vape",
          description: "Easy-to-use disposable with smooth vapor production.",
          price: 29.99,
          rating: 4.7,
          reviews: 203,
          link: "/delta-8-vapes"
        }
      ],
      feedback: {
        experience: "Based on your experience level, we recommend starting with these user-friendly products.",
        effects: "These products are known for providing the relaxing effects you're looking for.",
        price: "These options fit within your specified budget while maintaining high quality."
      }
    };
  };

  const recommendations = getRecommendations();

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-8"
    >
      <div className="bg-herb-light bg-opacity-10 rounded-lg p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Your Personalized Recommendations</h2>
        <div className="space-y-4 text-gray-600">
          <p>{recommendations.feedback.experience}</p>
          <p>{recommendations.feedback.effects}</p>
          <p>{recommendations.feedback.price}</p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {recommendations.products.map((product, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-lg shadow-lg p-6"
          >
            <h3 className="text-xl font-bold text-gray-900 mb-2">{product.name}</h3>
            <p className="text-gray-600 mb-4">{product.description}</p>
            <div className="flex items-center mb-4">
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <span key={i} className="text-yellow-400">★</span>
                ))}
              </div>
              <span className="ml-2 text-gray-600">
                {product.rating} ({product.reviews} reviews)
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-2xl font-bold text-gray-900">${product.price}</span>
              <Link
                to={product.link}
                className="bg-herb text-white px-6 py-2 rounded-lg hover:bg-herb-dark transition-colors"
              >
                View Details
              </Link>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="flex justify-between items-center pt-6 border-t border-gray-200">
        <button
          onClick={onStartOver}
          className="text-gray-600 hover:text-gray-800 transition-colors"
        >
          ← Take Quiz Again
        </button>
        <Link
          to="/products"
          className="bg-herb text-white px-6 py-2 rounded-lg hover:bg-herb-dark transition-colors"
        >
          Browse All Products →
        </Link>
      </div>
    </motion.div>
  );
}