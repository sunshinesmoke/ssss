import React from 'react';
import { motion } from 'framer-motion';
import useCartStore from '../store/cartStore';
import toast from 'react-hot-toast';

export default function ProductCard({ product }) {
  const addItem = useCartStore(state => state.addItem);

  const handleAddToCart = () => {
    addItem(product);
    toast.success(`${product.name} added to cart!`);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-lg shadow-md p-6"
    >
      <div className="flex flex-col h-full">
        <div className="flex-grow">
          <span className="text-sm font-medium text-blue-600">{product.category}</span>
          <h3 className="text-lg font-semibold text-gray-900 mt-1">{product.name}</h3>
          <p className="text-gray-500 text-sm mt-2">{product.description}</p>
        </div>
        <div className="mt-4">
          <p className="text-lg font-bold text-gray-900">${product.price.toFixed(2)}</p>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleAddToCart}
            className="mt-2 w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
          >
            Add to Cart
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
}