import React from 'react';
import { motion } from 'framer-motion';

const deals = [
  {
    id: 1,
    title: "Bundle & Save",
    description: "Buy 2 THCA vapes, get a free pre-roll",
    tag: "POPULAR",
    icon: "🎁"
  },
  {
    id: 2,
    title: "First-Time Special",
    description: "15% off your first purchase",
    tag: "NEW CUSTOMERS",
    icon: "🌟"
  },
  {
    id: 3,
    title: "VIP Box",
    description: "Monthly subscription box with exclusive products",
    tag: "MEMBERS ONLY",
    icon: "📦"
  }
];

export default function ExclusiveDeals() {
  return (
    <div className="bg-herb-light bg-opacity-5 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900">Exclusive Deals</h2>
          <p className="mt-4 text-lg text-gray-600">
            Special offers you won't find anywhere else
          </p>
        </div>

        <div className="mt-12 grid gap-8 md:grid-cols-3">
          {deals.map((deal, index) => (
            <motion.div
              key={deal.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-lg shadow-lg overflow-hidden"
            >
              <div className="bg-gradient-to-r from-herb-dark to-herb p-1">
                <div className="text-xs font-medium text-white text-center">
                  {deal.tag}
                </div>
              </div>
              <div className="p-6">
                <div className="text-3xl mb-4">{deal.icon}</div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{deal.title}</h3>
                <p className="text-gray-600">{deal.description}</p>
                <button className="mt-4 w-full bg-herb-light text-white py-2 px-4 rounded-md hover:bg-herb transition-colors">
                  Claim Deal
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}