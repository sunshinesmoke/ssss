import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

export default function AgeGate({ isOpen, onVerify }) {
  const navigate = useNavigate();

  const handleVerify = () => {
    localStorage.setItem('age-verified', 'true');
    onVerify();
  };

  const handleDeny = () => {
    window.location.href = 'https://www.google.com';
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black bg-opacity-75 z-50 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-white rounded-xl p-8 max-w-md w-full shadow-2xl"
        >
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Sunshine Smoke Shop</h1>
            <div className="w-16 h-1 bg-gradient-to-r from-primary-500 to-secondary-500 mx-auto mb-6"></div>
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">Age Verification Required</h2>
            <div className="bg-primary-50 border border-primary-100 rounded-lg p-4 mb-6">
              <p className="text-gray-700 font-medium mb-2">
                Welcome to Sunshine Smoke Shop!
              </p>
              <p className="text-gray-600">
                You must be 21 years or older to enter our website.
              </p>
            </div>
            <p className="text-sm text-gray-500 italic">
              By clicking "I'm 21 or Older" you verify that you are of legal age to view this content.
            </p>
          </div>
          <div className="space-y-3">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleVerify}
              className="w-full bg-gradient-to-r from-primary-500 to-secondary-500 text-white py-4 px-6 rounded-lg font-semibold hover:from-primary-600 hover:to-secondary-600 transition-all shadow-lg"
            >
              I'm 21 or Older
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleDeny}
              className="w-full bg-gray-100 text-gray-700 py-4 px-6 rounded-lg font-medium hover:bg-gray-200 transition-all"
            >
              I'm Under 21
            </motion.button>
          </div>
          <p className="text-xs text-gray-400 text-center mt-6">
            Orlando & Kissimmee's Premier Smoke Shop
          </p>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}