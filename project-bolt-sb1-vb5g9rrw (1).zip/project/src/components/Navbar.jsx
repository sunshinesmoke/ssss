import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Disclosure } from '@headlessui/react';
import { Bars3Icon as MenuIcon, XMarkIcon as XIcon, UserIcon } from '@heroicons/react/24/outline';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';
import { useTranslation } from 'react-i18next';
import LanguageSelector from './LanguageSelector';

const navigation = [
  { name: 'nav.home', href: '/' },
  { name: 'nav.quiz', href: '/quiz' },
  { name: 'nav.blog', href: '/blog' },
  { name: 'nav.thcaVsThc', href: '/thca-vs-thc' },
  { name: 'nav.labReport', href: '/lab-report-guide' },
  { name: 'nav.vapeGuide', href: '/vape-guide' },
  { name: 'nav.cigars', href: '/cigars' },
  { name: 'nav.rewards', href: '/rewards' },
  { name: 'nav.careers', href: '/careers' },
  { name: 'nav.about', href: '/about' },
  { name: 'nav.contact', href: '/contact' },
];

export default function Navbar() {
  const navigate = useNavigate();
  const [user, setUser] = React.useState(null);
  const { t } = useTranslation();

  React.useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleSignOut = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      toast.success('Successfully signed out');
      navigate('/');
    } catch (error) {
      toast.error(error.message);
    }
  };

  return (
    <Disclosure as="nav" className="bg-gradient-to-r from-herb-dark to-herb relative">
      {({ open }) => (
        <>
          <div className="absolute inset-0 bg-leaf-pattern opacity-10"></div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
            <div className="flex justify-between h-16">
              <div className="flex">
                <div className="flex-shrink-0 flex items-center">
                  <Link to="/" className="text-2xl font-bold text-white flex items-center space-x-2">
                    <span className="text-secondary-300">☀️</span>
                    <span>Sunshine Smoke</span>
                  </Link>
                </div>
                <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
                  {navigation.map((item) => (
                    <Link
                      key={item.name}
                      to={item.href}
                      className="text-white hover:text-secondary-200 px-3 py-2 rounded-md text-sm font-medium transition-colors"
                    >
                      {t(item.name)}
                    </Link>
                  ))}
                </div>
              </div>
              <div className="hidden sm:ml-6 sm:flex sm:items-center space-x-4">
                <LanguageSelector />
                {user ? (
                  <button
                    onClick={handleSignOut}
                    className="text-white hover:text-secondary-200 px-3 py-2 rounded-md text-sm font-medium transition-colors"
                  >
                    {t('nav.signOut')}
                  </button>
                ) : (
                  <Link
                    to="/login"
                    className="flex items-center text-white hover:text-secondary-200 px-3 py-2 rounded-md text-sm font-medium transition-colors"
                  >
                    <UserIcon className="h-5 w-5 mr-1" />
                    {t('nav.signIn')}
                  </Link>
                )}
              </div>
              <div className="-mr-2 flex items-center sm:hidden">
                <Disclosure.Button className="inline-flex items-center justify-center p-2 rounded-md text-white hover:text-secondary-200 hover:bg-herb-dark">
                  {open ? (
                    <XIcon className="block h-6 w-6" />
                  ) : (
                    <MenuIcon className="block h-6 w-6" />
                  )}
                </Disclosure.Button>
              </div>
            </div>
          </div>

          <Disclosure.Panel className="sm:hidden bg-herb-dark relative">
            <div className="absolute inset-0 bg-leaf-pattern opacity-10"></div>
            <div className="pt-2 pb-3 space-y-1 relative">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  className="block px-3 py-2 text-white hover:text-secondary-200 hover:bg-herb text-base font-medium transition-colors"
                >
                  {t(item.name)}
                </Link>
              ))}
              <div className="px-3 py-2">
                <LanguageSelector />
              </div>
              {user ? (
                <button
                  onClick={handleSignOut}
                  className="block w-full text-left px-3 py-2 text-white hover:text-secondary-200 hover:bg-herb text-base font-medium transition-colors"
                >
                  {t('nav.signOut')}
                </button>
              ) : (
                <Link
                  to="/login"
                  className="block px-3 py-2 text-white hover:text-secondary-200 hover:bg-herb text-base font-medium transition-colors"
                >
                  {t('nav.signIn')}
                </Link>
              )}
            </div>
          </Disclosure.Panel>
        </>
      )}
    </Disclosure>
  );
}