import React from 'react';
import { Helmet } from 'react-helmet-async';
import toast from 'react-hot-toast';

export default function Contact() {
  const handleSubmit = (e) => {
    e.preventDefault();
    // Send form data to info@sunshinesmoke.com
    window.location.href = `mailto:info@sunshinesmoke.com?subject=Contact Form Submission&body=${encodeURIComponent(
      `Name: ${e.target.name.value}\nEmail: ${e.target.email.value}\nPhone: ${e.target.phone.value}\nLocation: ${e.target.location.value}\nMessage: ${e.target.message.value}`
    )}`;
    toast.success('Thank you for your message! We will get back to you soon.');
  };

  return (
    <>
      <Helmet>
        <title>Contact Sunshine Smoke Shop | 24/7 Vape & THCA Delivery Orlando</title>
        <meta name="description" content="Contact Sunshine Smoke Shop for 24/7 vape and THCA delivery in Orlando & Kissimmee. Five convenient locations near Disney World, Universal Studios, and International Drive." />
        <meta name="keywords" content="smoke shop contact Orlando, vape delivery Kissimmee, THCA delivery Disney World, CBD store locations, smoke shop near Universal Studios, vape shop International Drive" />
        <link rel="canonical" href="https://sunshinesmoke.com/contact" />
      </Helmet>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Contact Us</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Our Locations</h2>
            
            {/* Orlando Locations */}
            <div className="space-y-6">
              <h3 className="font-semibold text-gray-900 text-lg">Orlando Stores</h3>
              
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="space-y-3">
                  <p className="text-gray-600">
                    8216 World Center Drive, Suite D<br />
                    Orlando, FL 32821
                  </p>
                  <p className="text-gray-600">
                    <strong>Phone:</strong> (407) 778-1326
                  </p>
                  <p className="text-green-600 font-medium">
                    <strong>Hours:</strong> Open 24/7
                  </p>
                  <a 
                    href="https://maps.google.com/?q=8216+World+Center+Drive,+Suite+D,+Orlando,+FL+32821" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-block text-blue-600 hover:text-blue-800 transition-colors"
                  >
                    Get Directions →
                  </a>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="space-y-3">
                  <p className="text-gray-600">
                    6203 W Sand Lake Rd, Suite C<br />
                    Orlando, FL 32819
                  </p>
                  <p className="text-gray-600">
                    <strong>Phone:</strong> (321) 440-4191
                  </p>
                  <p className="text-gray-600">
                    <strong>Hours:</strong> 9:00 AM - 2:00 AM Daily
                  </p>
                  <a 
                    href="https://maps.google.com/?q=6203+W+Sand+Lake+Rd,+Suite+C,+Orlando,+FL+32819" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-block text-blue-600 hover:text-blue-800 transition-colors"
                  >
                    Get Directions →
                  </a>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="space-y-3">
                  <p className="text-gray-600">
                    5661 Vineland Rd<br />
                    Orlando, FL 32819
                  </p>
                  <p className="text-gray-600">
                    <strong>Phone:</strong> (321) 440-4191
                  </p>
                  <p className="text-gray-600">
                    <strong>Hours:</strong> 9:00 AM - 2:00 AM Daily
                  </p>
                  <a 
                    href="https://maps.google.com/?q=5661+Vineland+Rd,+Orlando,+FL+32819" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-block text-blue-600 hover:text-blue-800 transition-colors"
                  >
                    Get Directions →
                  </a>
                </div>
              </div>
            </div>

            {/* Kissimmee Locations */}
            <div className="space-y-6">
              <h3 className="font-semibold text-gray-900 text-lg">Kissimmee Stores</h3>
              
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="space-y-3">
                  <p className="text-gray-600">
                    5192 W Irlo Bronson Memorial Hwy<br />
                    Kissimmee, FL 34746
                  </p>
                  <p className="text-gray-600">
                    <strong>Phone:</strong> (321) 440-4191
                  </p>
                  <p className="text-green-600 font-medium">
                    <strong>Hours:</strong> Open 24/7
                  </p>
                  <a 
                    href="https://maps.google.com/?q=5192+W+Irlo+Bronson+Memorial+Hwy,+Kissimmee,+FL+34746" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-block text-blue-600 hover:text-blue-800 transition-colors"
                  >
                    Get Directions →
                  </a>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="space-y-3">
                  <p className="text-gray-600">
                    7726 W Irlo Bronson Memorial Hwy<br />
                    Kissimmee, FL 34747
                  </p>
                  <p className="text-gray-600">
                    <strong>Phone:</strong> (321) 440-4191
                  </p>
                  <p className="text-gray-600">
                    <strong>Hours:</strong> 9:00 AM - 2:00 AM Daily
                  </p>
                  <a 
                    href="https://maps.google.com/?q=7726+W+Irlo+Bronson+Memorial+Hwy,+Kissimmee,+FL+34747" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-block text-blue-600 hover:text-blue-800 transition-colors"
                  >
                    Get Directions →
                  </a>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-r from-primary-50 to-secondary-50 rounded-lg p-6">
              <h3 className="font-semibold text-gray-900 text-lg mb-4">General Contact</h3>
              <div className="space-y-3">
                <p className="text-gray-600">
                  <strong>Email:</strong>{' '}
                  <a href="mailto:info@sunshinesmoke.com" className="text-blue-600 hover:text-blue-800 transition-colors">
                    info@sunshinesmoke.com
                  </a>
                </p>
                <p className="text-gray-600">
                  <strong>Main Phone:</strong> (407) 778-1326
                </p>
              </div>
            </div>
          </div>
          
          <div>
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Send us a Message</h2>
            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6">
              <div className="mb-4">
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">Name</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                  required
                />
              </div>
              
              <div className="mb-4">
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                  required
                />
              </div>

              <div className="mb-4">
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700">Phone Number</label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                />
              </div>
              
              <div className="mb-4">
                <label htmlFor="location" className="block text-sm font-medium text-gray-700">Preferred Location</label>
                <select
                  id="location"
                  name="location"
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                >
                  <option value="">Select a location</option>
                  <option value="world-center">Orlando - World Center Dr</option>
                  <option value="sand-lake">Orlando - Sand Lake Rd</option>
                  <option value="vineland">Orlando - Vineland Rd</option>
                  <option value="kissimmee-192">Kissimmee - W Irlo Bronson (192)</option>
                  <option value="kissimmee-27">Kissimmee - W Irlo Bronson (27)</option>
                </select>
              </div>
              
              <div className="mb-4">
                <label htmlFor="message" className="block text-sm font-medium text-gray-700">Message</label>
                <textarea
                  id="message"
                  name="message"
                  rows={4}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                  required
                ></textarea>
              </div>
              
              <button
                type="submit"
                className="w-full bg-gradient-to-r from-primary-600 to-secondary-500 text-white py-3 px-4 rounded-md hover:from-primary-700 hover:to-secondary-600 transition-colors font-medium"
              >
                Send Message
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
}