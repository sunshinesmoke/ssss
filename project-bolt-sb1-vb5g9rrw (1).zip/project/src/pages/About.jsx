import React from 'react';
import { Helmet } from 'react-helmet-async';

export default function About() {
  return (
    <>
      <Helmet>
        <title>About Sunshine Smoke Shop | Premier Smoke Shop in Orlando & Kissimmee</title>
        <meta name="description" content="Learn about Sunshine Smoke Shop, Orlando & Kissimmee's premier smoke shop. Quality vapes, THCA products, and smoking accessories near Disney World, Universal Studios, and International Drive." />
        <meta name="keywords" content="smoke shop Orlando, vape store Kissimmee, THCA dispensary Disney World, CBD shop Universal Studios, smoke shop International Drive, vape delivery Orlando" />
        <link rel="canonical" href="https://sunshinesmoke.com/about" />
      </Helmet>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">About Sunshine Smoke</h1>
        
        <div className="prose prose-lg max-w-none">
          <div className="bg-white rounded-lg shadow-md p-8 mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">Why Choose Sunshine Smoke? 🌞💨 – Orlando & Kissimmee's #1 Smoke Shop</h2>
            <h3 className="text-xl font-semibold text-gray-900 mb-3">Premium THCA, Vapes & Smoking Accessories</h3>
            <p className="text-gray-600 mb-6">
              At Sunshine Smoke, we bring Orlando, Kissimmee, and Disney-area customers the highest quality THCA, vapes, and smoking accessories. Whether you're a local or visiting Florida's top attractions, we've got everything you need.
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-8 mb-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">What Sets Us Apart?</h2>
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">🔥 Quality Products</h3>
                <p className="text-gray-600">
                  We carefully select every product in our stores, ensuring top-tier THCA flower, disposable vapes, premium glass pieces, and smoking accessories. Only the best makes it to our shelves!
                </p>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">💡 Expert Staff</h3>
                <p className="text-gray-600">
                  Our team is knowledgeable and passionate about THCA, vapes, and smoke essentials. Need recommendations? We're here to help!
                </p>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">💰 Competitive Prices & Deals</h3>
                <p className="text-gray-600">
                  We keep our prices fair and offer exclusive deals so you get the best value on vapes, THCA carts, and accessories in Orlando & Kissimmee.
                </p>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">📍 Convenient Locations</h3>
                <p className="text-gray-600">
                  With five locations across Orlando and Kissimmee, including near Disney World, Universal Studios, and International Drive, we're always nearby when you need us.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">Our Commitment to Orlando & Kissimmee</h2>
            <ul className="list-none space-y-3 text-gray-600">
              <li>✔️ High-quality THCA, vapes, and smoking accessories</li>
              <li>✔️ Friendly, knowledgeable staff ready to assist</li>
              <li>✔️ Affordable prices with regular discounts</li>
              <li>✔️ A welcoming shopping experience for all</li>
              <li>✔️ Supporting the local community since 2018</li>
            </ul>
            <div className="mt-8 text-gray-600">
              <p>🛒 Visit us in-store or shop online for fast delivery in Orlando, Kissimmee, and beyond! 🚀💨</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}