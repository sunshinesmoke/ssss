import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';

export default function ReturnPolicy() {
  return (
    <>
      <Helmet>
        <title>Return Policy | Sunshine Smoke Shop - Orlando & Kissimmee</title>
        <meta name="description" content="Sunshine Smoke Shop's return policy for vapes, THCA products, and smoking accessories. Easy returns at our Orlando & Kissimmee locations near Disney World." />
        <meta name="keywords" content="smoke shop return policy, vape shop returns Orlando, CBD store refunds Kissimmee, THCA product returns, smoke shop near Disney World" />
        <link rel="canonical" href="https://sunshinesmoke.com/return-policy" />
      </Helmet>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-lg shadow-lg p-8"
        >
          <h1 className="text-3xl font-bold text-gray-900 mb-6">Return Policy</h1>

          <div className="prose prose-lg">
            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Overview</h2>
              <p className="text-gray-600 mb-4">
                At Sunshine Smoke Shop, we want you to be completely satisfied with your purchase. We understand that sometimes a product may not meet your expectations, and we're here to help.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Return Window</h2>
              <p className="text-gray-600 mb-4">
                We accept returns within 14 days of purchase, provided that:
              </p>
              <ul className="list-disc pl-6 text-gray-600 mb-4">
                <li>The item is unused and in its original packaging</li>
                <li>You have the original receipt or proof of purchase</li>
                <li>The item is not a final sale or clearance item</li>
                <li>The product has not been opened (for hygiene reasons)</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Non-Returnable Items</h2>
              <p className="text-gray-600 mb-4">
                For hygiene and safety reasons, the following items cannot be returned:
              </p>
              <ul className="list-disc pl-6 text-gray-600 mb-4">
                <li>Used or opened products</li>
                <li>Consumable items</li>
                <li>Sale or clearance items</li>
                <li>Gift cards</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Refund Process</h2>
              <p className="text-gray-600 mb-4">
                Refunds will be processed in the original form of payment:
              </p>
              <ul className="list-disc pl-6 text-gray-600 mb-4">
                <li>Credit card refunds typically process within 3-5 business days</li>
                <li>Cash refunds are available immediately in-store</li>
                <li>Store credit is available if you don't have the original receipt</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Exchanges</h2>
              <p className="text-gray-600 mb-4">
                We're happy to exchange items within 14 days of purchase for:
              </p>
              <ul className="list-disc pl-6 text-gray-600 mb-4">
                <li>Different size or color (if available)</li>
                <li>Different product of equal or greater value (paying the difference)</li>
                <li>Store credit for future purchases</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Damaged or Defective Items</h2>
              <p className="text-gray-600 mb-4">
                If you receive a damaged or defective item:
              </p>
              <ul className="list-disc pl-6 text-gray-600 mb-4">
                <li>Contact us immediately upon discovery</li>
                <li>We'll replace the item at no additional cost</li>
                <li>Return shipping for defective items is covered by us</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Contact Us</h2>
              <p className="text-gray-600 mb-4">
                If you have any questions about our return policy, please contact us:
              </p>
              <ul className="list-none text-gray-600">
                <li>Phone: (407) 778-1326</li>
                <li>Email: info@sunshinesmoke.com</li>
                <li>Visit any of our store locations</li>
              </ul>
            </section>
          </div>
        </motion.div>
      </div>
    </>
  );
}