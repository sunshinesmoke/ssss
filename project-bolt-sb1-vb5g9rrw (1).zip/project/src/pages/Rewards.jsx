import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const tiers = [
  {
    name: 'Silver',
    spend: '$250/year',
    benefits: [
      '1.5x points on all purchases',
      'Exclusive member deals',
      'Birthday reward bonus',
      'Early access to sales'
    ],
    color: 'bg-gray-100'
  },
  {
    name: 'Gold',
    spend: '$500/year',
    benefits: [
      '2x points on all purchases',
      'Free shipping on orders over $50',
      'All Silver benefits',
      'Monthly exclusive offers'
    ],
    color: 'bg-yellow-50'
  },
  {
    name: 'Platinum',
    spend: '$1,000/year',
    benefits: [
      '3x points on all purchases',
      'Free shipping on all orders',
      'Early product releases',
      'VIP giveaways & events'
    ],
    color: 'bg-primary-50'
  }
];

const rewards = [
  {
    points: 500,
    reward: '$5 Off Your Next Purchase',
    icon: '💰'
  },
  {
    points: 1000,
    reward: 'Free Disposable Vape or Pack of Gummies',
    icon: '🎁'
  },
  {
    points: 2500,
    reward: '$25 Off Any Order',
    icon: '🏷️'
  },
  {
    points: 5000,
    reward: 'VIP Access to Exclusive Drops & Discounts',
    icon: '⭐'
  }
];

export default function Rewards() {
  return (
    <>
      <Helmet>
        <title>Rewards Program | Sunshine Smoke Shop Orlando & Kissimmee</title>
        <meta name="description" content="Join Sunshine Smoke Shop's rewards program. Earn points on every purchase, get exclusive discounts, and enjoy VIP benefits at our Orlando & Kissimmee locations." />
        <meta name="keywords" content="smoke shop rewards, vape store points, CBD loyalty program, smoke shop membership Orlando, vape rewards Kissimmee" />
      </Helmet>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-bold text-gray-900 mb-4"
          >
            Sunshine Smoke Rewards Program
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-gray-600"
          >
            Stay Loyal, Earn Rewards, Enjoy More!
          </motion.p>
        </div>

        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-16"
        >
          <h2 className="text-2xl font-bold text-gray-900 mb-6">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                title: 'Sign Up & Start Earning',
                description: 'Create a free account and automatically earn points with every purchase.',
                icon: '📝'
              },
              {
                title: 'Earn Points',
                description: 'Get 1 point for every $1 spent on cigars, vapes, gummies, and more.',
                icon: '💎'
              },
              {
                title: 'Bonus Points',
                description: 'Earn extra points for referrals, reviews, and social media follows.',
                icon: '🎉'
              },
              {
                title: 'Redeem Rewards',
                description: 'Use points for discounts, free products, and exclusive items.',
                icon: '🎁'
              }
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index }}
                className="bg-white rounded-lg shadow-md p-6"
              >
                <div className="text-4xl mb-4">{item.icon}</div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-gray-600">{item.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-16"
        >
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Available Rewards</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {rewards.map((reward, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index }}
                className="bg-white rounded-lg shadow-md p-6 text-center"
              >
                <div className="text-4xl mb-4">{reward.icon}</div>
                <div className="text-2xl font-bold text-primary-600 mb-2">
                  {reward.points} Points
                </div>
                <p className="text-gray-600">{reward.reward}</p>
              </motion.div>
            ))}
          </div>
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-16"
        >
          <h2 className="text-2xl font-bold text-gray-900 mb-6">VIP Tiers</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {tiers.map((tier, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index }}
                className={`${tier.color} rounded-lg shadow-md p-6`}
              >
                <h3 className="text-xl font-bold text-gray-900 mb-2">{tier.name}</h3>
                <p className="text-primary-600 font-semibold mb-4">{tier.spend}</p>
                <ul className="space-y-2">
                  {tier.benefits.map((benefit, benefitIndex) => (
                    <li key={benefitIndex} className="flex items-center text-gray-700">
                      <span className="text-green-500 mr-2">✓</span>
                      {benefit}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="text-center"
        >
          <div className="bg-gradient-to-r from-primary-500 to-secondary-500 text-white rounded-lg p-8">
            <h2 className="text-2xl font-bold mb-4">Join Our Rewards Program Today!</h2>
            <p className="text-lg mb-6">
              Start earning points and enjoying exclusive benefits with every purchase.
            </p>
            <Link
              to="/register"
              className="inline-block bg-white text-primary-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
            >
              Sign Up Now
            </Link>
          </div>
        </motion.section>
      </div>
    </>
  );
}