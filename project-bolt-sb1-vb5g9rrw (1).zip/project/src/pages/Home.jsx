import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChevronRightIcon } from '@heroicons/react/24/outline';
import NearestLocation from '../components/NearestLocation';

export default function Home() {
  return (
    <>
      <Helmet>
        <title>Best Smoke Shop in Orlando & Kissimmee | THCA, Vapes & CBD Near Disney World</title>
        <meta name="description" content="Orlando & Kissimmee's premier smoke shop offering 24/7 vape delivery, THCA products, CBD near Disney World, and disposable vapes. Visit our locations near Universal Studios and International Drive!" />
        <meta name="keywords" content="smoke shop Orlando, vape store Orlando, smoke shop Kissimmee, best vape shop in Orlando, CBD store Orlando, THC vapes Kissimmee, THCA flower Orlando, disposable vapes near me, hookah shop Orlando, Delta-8 in Orlando" />
      </Helmet>

      {/* Hero Section */}
      <div className="relative bg-gradient-to-r from-herb-dark to-herb">
        <div className="absolute inset-0 bg-leaf-pattern opacity-10"></div>
        <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl"
          >
            #1 THCA & Vape Shop in Orlando 🌿
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mt-6 text-xl text-gray-100 max-w-3xl"
          >
            Premium THCA flower, vapes, and CBD products with fast delivery in Orlando, Kissimmee, and near Disney World. Open 24/7 with multiple locations!
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="mt-10"
          >
            <Link
              to="/quiz"
              className="inline-flex items-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-black bg-yellow-400 hover:bg-yellow-500 transition-colors"
            >
              Find Your Perfect Product
              <ChevronRightIcon className="ml-2 -mr-1 h-5 w-5" aria-hidden="true" />
            </Link>
          </motion.div>
        </div>
      </div>

      {/* Nearest Location Section */}
      <div className="bg-gray-50 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900">Find Your Nearest Smoke Shop</h2>
            <p className="mt-4 text-lg text-gray-600">
              Multiple locations in Orlando & Kissimmee near Disney World, Universal Studios, and International Drive
            </p>
          </div>
          <NearestLocation />
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-gradient-to-r from-herb-dark to-herb relative">
        <div className="absolute inset-0 bg-leaf-pattern opacity-10"></div>
        <div className="relative max-w-7xl mx-auto py-16 px-4 sm:py-24 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
              Orlando's Premier Smoke Shop
            </h2>
            <p className="mt-4 text-lg text-smoke-light">
              Quality products, expert staff, and unmatched service
            </p>
          </div>

          <div className="mt-12 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {[
              {
                title: 'Premium THCA Products',
                description: 'High-quality THCA flower, concentrates, and vapes',
                icon: '🌿'
              },
              {
                title: '24/7 Delivery',
                description: 'Fast delivery to Orlando, Kissimmee & Disney area',
                icon: '🚚'
              },
              {
                title: 'Expert Staff',
                description: 'Knowledgeable team for personalized recommendations',
                icon: '👨‍💼'
              },
              {
                title: 'Multiple Locations',
                description: 'Convenient stores near major attractions',
                icon: '📍'
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white/10 backdrop-blur-lg rounded-lg p-6"
              >
                <div className="text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-lg font-medium text-white">{feature.title}</h3>
                <p className="mt-2 text-smoke-light">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Popular Products Section */}
      <div className="bg-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900">Popular Products</h2>
            <p className="mt-4 text-lg text-gray-600">
              Browse our selection of premium smoking products
            </p>
          </div>

          <div className="mt-12 grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-4">
            {[
              {
                name: 'THCA Flower',
                description: 'Premium hemp-derived THCA flower',
                price: '$39.99'
              },
              {
                name: 'Disposable Vapes',
                description: 'Convenient and portable vaping',
                price: '$29.99'
              },
              {
                name: 'Delta-8 Products',
                description: 'Wide selection of Delta-8 items',
                price: '$34.99'
              },
              {
                name: 'CBD Gummies',
                description: 'Delicious CBD-infused edibles',
                price: '$24.99'
              }
            ].map((product, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
              >
                <div className="mt-4">
                  <h3 className="text-lg font-medium text-gray-900">{product.name}</h3>
                  <p className="mt-1 text-sm text-gray-500">{product.description}</p>
                  <p className="mt-1 text-lg font-medium text-gray-900">{product.price}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}