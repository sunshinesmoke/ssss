import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const nicotineQuestions = [
  {
    id: 1,
    question: "What's your experience with nicotine products?",
    options: [
      { id: 'beginner', text: 'Beginner - New to vaping' },
      { id: 'intermediate', text: 'Intermediate - Occasional vaper' },
      { id: 'advanced', text: 'Advanced - Regular vaper' },
      { id: 'expert', text: 'Expert - Vaping enthusiast' }
    ]
  },
  {
    id: 2,
    question: "What type of device are you looking for?",
    options: [
      { id: 'disposable', text: 'Disposable - Simple & convenient' },
      { id: 'pod', text: 'Pod System - Refillable & compact' },
      { id: 'mod', text: 'Box Mod - Advanced features' },
      { id: 'mechanical', text: 'Mechanical Mod - Expert users' }
    ]
  },
  {
    id: 3,
    question: "Preferred nicotine strength?",
    options: [
      { id: 'low', text: '3-6mg - Light strength' },
      { id: 'medium', text: '12mg - Medium strength' },
      { id: 'high', text: '25-50mg - High strength (Salt Nic)' },
      { id: 'zero', text: '0mg - No nicotine' }
    ]
  }
];

const cannabisQuestions = [
  {
    id: 1,
    question: "What's your experience with cannabis products?",
    options: [
      { id: 'beginner', text: 'Beginner - New to cannabis' },
      { id: 'intermediate', text: 'Intermediate - Occasional user' },
      { id: 'advanced', text: 'Advanced - Regular user' },
      { id: 'expert', text: 'Expert - Cannabis connoisseur' }
    ]
  },
  {
    id: 2,
    question: "What type of product interests you?",
    options: [
      { id: 'flower', text: 'THCA Flower - Traditional experience' },
      { id: 'vape', text: 'Vapes - Convenient & discrete' },
      { id: 'edible', text: 'Edibles - Long-lasting effects' },
      { id: 'concentrate', text: 'Concentrates - Maximum potency' }
    ]
  },
  {
    id: 3,
    question: "What effects are you looking for?",
    options: [
      { id: 'relax', text: 'Relaxation & Stress Relief' },
      { id: 'energy', text: 'Energy & Focus' },
      { id: 'sleep', text: 'Sleep Aid' },
      { id: 'pain', text: 'Pain Relief' }
    ]
  }
];

export default function Quiz() {
  const [productType, setProductType] = useState(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [showResults, setShowResults] = useState(false);

  const questions = productType === 'nicotine' ? nicotineQuestions : cannabisQuestions;

  const handleProductTypeSelect = (type) => {
    setProductType(type);
    setCurrentQuestion(0);
    setAnswers({});
    setShowResults(false);
  };

  const handleAnswer = (answerId) => {
    setAnswers({ ...answers, [questions[currentQuestion].id]: answerId });
    
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setShowResults(true);
    }
  };

  const resetQuiz = () => {
    setProductType(null);
    setCurrentQuestion(0);
    setAnswers({});
    setShowResults(false);
  };

  if (!productType) {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-lg shadow-xl p-8">
          <h1 className="text-2xl font-bold text-gray-900 mb-6 text-center">
            What type of products are you interested in?
          </h1>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleProductTypeSelect('nicotine')}
              className="bg-blue-500 text-white p-8 rounded-lg text-center hover:bg-blue-600 transition-colors"
            >
              <span className="text-4xl mb-4 block">💨</span>
              <h2 className="text-xl font-bold mb-2">Nicotine Products</h2>
              <p className="text-sm">Vapes, disposables, and accessories</p>
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleProductTypeSelect('cannabis')}
              className="bg-green-500 text-white p-8 rounded-lg text-center hover:bg-green-600 transition-colors"
            >
              <span className="text-4xl mb-4 block">🌿</span>
              <h2 className="text-xl font-bold mb-2">Cannabis Products</h2>
              <p className="text-sm">THCA, Delta-8, CBD, and more</p>
            </motion.button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Find Your Perfect Products | Sunshine Smoke Shop Quiz</title>
        <meta name="description" content="Take our quiz to find the perfect vape, THCA product, or smoking accessory. Expert recommendations from Orlando's premier smoke shop." />
        <meta name="keywords" content="vape quiz Orlando, THCA product finder, smoke shop recommendations, CBD quiz near Disney World" />
      </Helmet>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-lg shadow-xl p-8">
          {!showResults ? (
            <>
              <div className="mb-8">
                <div className="flex justify-between items-center mb-4">
                  <h1 className="text-2xl font-bold text-gray-900">
                    Find Your Perfect {productType === 'nicotine' ? 'Vape' : 'Cannabis'} Product
                  </h1>
                  <span className="text-sm text-gray-500">
                    Question {currentQuestion + 1} of {questions.length}
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <motion.div
                    className={`h-2 rounded-full ${
                      productType === 'nicotine' ? 'bg-blue-600' : 'bg-green-600'
                    }`}
                    initial={{ width: 0 }}
                    animate={{
                      width: `${((currentQuestion + 1) / questions.length) * 100}%`
                    }}
                    transition={{ duration: 0.5 }}
                  />
                </div>
              </div>

              <motion.div
                key={currentQuestion}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                <h2 className="text-xl font-semibold text-gray-900 mb-6">
                  {questions[currentQuestion].question}
                </h2>
                <div className="space-y-4">
                  {questions[currentQuestion].options.map((option) => (
                    <motion.button
                      key={option.id}
                      onClick={() => handleAnswer(option.id)}
                      className={`w-full text-left px-6 py-4 border-2 border-gray-200 rounded-lg hover:border-${
                        productType === 'nicotine' ? 'blue' : 'green'
                      }-500 hover:bg-${
                        productType === 'nicotine' ? 'blue' : 'green'
                      }-50 transition-colors`}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      {option.text}
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            </>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                Your Personalized Recommendations
              </h2>
              {/* Add recommendation logic based on answers */}
              <div className="space-y-6 mb-8">
                {/* Example recommendation */}
                <div className="border-2 border-gray-200 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    Based on your preferences
                  </h3>
                  <p className="text-gray-600 mb-4">
                    We recommend exploring our selection of {productType === 'nicotine' ? 'premium vapes' : 'THCA products'}.
                  </p>
                </div>
              </div>
              <div className="flex justify-between">
                <button
                  onClick={resetQuiz}
                  className="px-6 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
                >
                  Start Over
                </button>
                <Link
                  to={productType === 'nicotine' ? '/nicotine-disposables' : '/thca-flower'}
                  className={`px-6 py-3 text-white rounded-lg transition-colors ${
                    productType === 'nicotine'
                      ? 'bg-blue-600 hover:bg-blue-700'
                      : 'bg-green-600 hover:bg-green-700'
                  }`}
                >
                  Shop Recommended Products
                </Link>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </>
  );
}