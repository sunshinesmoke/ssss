import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';

const products = [
  {
    id: 'elf-bar-bc5000',
    name: "Elf Bar BC5000 Disposable",
    description: "The Elf Bar BC5000 features a 650mAh rechargeable battery and 13mL pre-filled e-liquid capacity, delivering up to 5000 puffs. Mesh coil technology for enhanced flavor.",
    price: 18.99,
    nicotine: "50mg",
    puffs: "5000",
    flavors: [
      "Strawberry Banana",
      "Blue Razz Ice",
      "Watermelon Bubblegum",
      "Peach Mango"
    ]
  },
  {
    id: 'lost-mary-bm600',
    name: "Lost Mary BM600 Disposable",
    description: "Compact disposable device with 2% nicotine salt e-liquid. Features a 550mAh battery and 2mL capacity for approximately 600 puffs.",
    price: 9.99,
    nicotine: "20mg",
    puffs: "600",
    flavors: [
      "Cool Mint",
      "Blueberry Ice",
      "Strawberry Ice",
      "Grape"
    ]
  },
  {
    id: 'fume-extra',
    name: "Fume Extra Disposable",
    description: "Pre-filled with 6mL of premium e-liquid, delivering up to 1500 puffs. Features a sleek design and draw-activated firing mechanism.",
    price: 12.99,
    nicotine: "50mg",
    puffs: "1500",
    flavors: [
      "Blue Razz",
      "Pina Colada",
      "Fresh Vanilla",
      "Tropical Fruit"
    ]
  },
  {
    id: 'flum-float',
    name: "Flum Float Disposable",
    description: "8mL pre-filled disposable with a 1100mAh battery. Delivers approximately 3000 puffs with consistent flavor production.",
    price: 16.99,
    nicotine: "50mg",
    puffs: "3000",
    flavors: [
      "Aloe Grape",
      "Mixed Berries",
      "Strawberry Ice Cream",
      "Cool Mint"
    ]
  },
  {
    id: 'hyde-edge',
    name: "Hyde Edge Disposable",
    description: "Featuring 10mL of premium e-liquid and a long-lasting battery. Delivers up to 3300 puffs with excellent flavor quality.",
    price: 17.99,
    nicotine: "50mg",
    puffs: "3300",
    flavors: [
      "Banana Ice",
      "Peach Mango Watermelon",
      "Blue Razz Ice",
      "Strawberry Apple"
    ]
  }
];

export default function NicotineDisposables() {
  return (
    <>
      <Helmet>
        <title>Premium Disposable Vapes | Sunshine Smoke Shop Orlando</title>
        <meta name="description" content="Shop premium disposable vapes in Orlando & Kissimmee. Wide selection of Elf Bar, Lost Mary, Fume, and more. Visit our stores near Disney World and Universal Studios." />
        <meta name="keywords" content="disposable vapes Orlando, Elf Bar Kissimmee, Lost Mary vape Disney area, Fume vape Universal Studios, vape shop International Drive" />
      </Helmet>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Premium Disposable Vapes</h1>
          <p className="text-xl text-gray-600">
            Top brands and latest flavors available in Orlando & Kissimmee
          </p>
        </div>

        <div className="bg-herb-light bg-opacity-5 rounded-lg p-6 mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Why Choose Our Disposables?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                title: "Authentic Products",
                description: "100% authentic products from authorized distributors",
                icon: "✓"
              },
              {
                title: "Fresh Stock",
                description: "Regular inventory updates for maximum freshness",
                icon: "🆕"
              },
              {
                title: "Expert Support",
                description: "Knowledgeable staff to help you choose the right device",
                icon: "👨‍💼"
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-lg p-6"
              >
                <div className="text-3xl mb-3">{feature.icon}</div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {products.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-lg shadow-lg p-6"
            >
              <div className="mb-4">
                <span className="inline-block bg-herb-light bg-opacity-10 text-herb-dark px-3 py-1 rounded-full text-sm font-medium">
                  {product.puffs} Puffs
                </span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{product.name}</h3>
              <p className="text-gray-600 mb-4">{product.description}</p>
              <div className="space-y-2 mb-4">
                <p className="text-gray-700">
                  <span className="font-semibold">Nicotine:</span> {product.nicotine}
                </p>
                <div>
                  <span className="font-semibold text-gray-700">Available Flavors:</span>
                  <ul className="mt-1 space-y-1">
                    {product.flavors.map((flavor, i) => (
                      <li key={i} className="text-gray-600 flex items-center">
                        <span className="text-xs mr-2">•</span>
                        {flavor}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-2xl font-bold text-gray-900">${product.price}</span>
                <button className="bg-herb hover:bg-herb-dark text-white px-6 py-2 rounded-lg transition-colors">
                  Add to Cart
                </button>
              </div>
            </motion.div>
          ))}
        </motion.div>

        <div className="mt-16 bg-white rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Frequently Asked Questions</h2>
          <div className="space-y-6">
            {[
              {
                question: "How long does a disposable vape last?",
                answer: "The lifespan depends on the specific device and your usage patterns. Our disposables range from 600 to 5000 puffs, with larger devices lasting several weeks for average users."
              },
              {
                question: "Are your disposable vapes authentic?",
                answer: "Yes! We only source our products from authorized distributors and verify authenticity codes on all devices."
              },
              {
                question: "Do you offer a warranty?",
                answer: "We offer a 48-hour warranty on all disposable devices. If you experience any issues, bring the device back to any of our locations with your receipt."
              }
            ].map((faq, index) => (
              <div key={index}>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{faq.question}</h3>
                <p className="text-gray-600">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}