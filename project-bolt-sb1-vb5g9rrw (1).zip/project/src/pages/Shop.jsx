import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import SearchFollowUpPopup from '../components/SearchFollowUpPopup';
import useSearchFollowUp from '../hooks/useSearchFollowUp';

const categories = {
  "Disposable Vapes": {
    icon: "💨",
    subcategories: ["Nicotine", "THCA", "THC", "Delta-8", "HHC"]
  },
  "Vape Cartridges": {
    icon: "🔋",
    subcategories: ["510 Thread", "THC", "Delta-8", "THCA Live Resin"]
  },
  "Flower": {
    icon: "🌿",
    subcategories: ["THCA", "THC", "Delta-8", "Pre-Rolls"]
  },
  "Edibles": {
    icon: "🍬",
    subcategories: ["THC", "Delta-8", "THCA", "CBD"]
  },
  "Concentrates": {
    icon: "💎",
    subcategories: ["Wax", "Live Resin", "THCA Diamonds"]
  },
  "Accessories": {
    icon: "🔧",
    subcategories: ["Papers", "Grinders", "Glass", "Dab Rigs"]
  }
};

const products = {
  "Disposable Vapes": [
    {
      id: 'vape-1',
      name: "THCA Live Resin Disposable",
      description: "Premium THCA live resin with natural terpenes. 2g capacity with rechargeable battery.",
      price: 39.99,
      category: "Disposable Vapes",
      subcategory: "THCA",
      effects: "Balanced, Uplifting"
    },
    {
      id: 'vape-2',
      name: "Delta-8 Disposable",
      description: "Smooth Delta-8 THC vape with long-lasting effects. 1g capacity.",
      price: 29.99,
      category: "Disposable Vapes",
      subcategory: "Delta-8",
      effects: "Relaxing, Mild"
    }
  ],
  "Flower": [
    {
      id: 'flower-1',
      name: "Premium THCA Flower",
      description: "Indoor-grown THCA flower with 28% THCA content. Lab tested for purity.",
      price: 29.99,
      category: "Flower",
      subcategory: "THCA",
      effects: "Potent, Clean"
    }
  ],
  "Edibles": [
    {
      id: 'edible-1',
      name: "Delta-8 Gummies",
      description: "25mg Delta-8 THC per gummy. Mixed fruit flavors.",
      price: 24.99,
      category: "Edibles",
      subcategory: "Delta-8",
      effects: "Long-lasting, Smooth"
    }
  ]
};

export default function Shop() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedSubcategory, setSelectedSubcategory] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [priceRange, setPriceRange] = useState('all');
  const [sortBy, setSortBy] = useState('featured');

  const { showFollowUp, setShowFollowUp, lastSearchTerm, handleSearch } = useSearchFollowUp();

  const nearestLocation = {
    name: "Sunshine Smoke Shop - World Center",
    address: "8216 World Center Drive, Suite D",
    city: "Orlando",
    state: "FL",
    zip: "32821",
    phone: "(321) 440-4191",
    hours: "Open 24/7"
  };

  const handleSearchChange = (e) => {
    const value = e.target.value;
    setSearchTerm(value);
    handleSearch(value);
  };

  const filteredProducts = React.useMemo(() => {
    let filtered = [];

    Object.entries(products).forEach(([category, items]) => {
      filtered = filtered.concat(items);
    });

    if (selectedCategory !== 'All') {
      filtered = filtered.filter(product => product.category === selectedCategory);
    }

    if (selectedSubcategory !== 'All') {
      filtered = filtered.filter(product => product.subcategory === selectedSubcategory);
    }

    if (searchTerm) {
      filtered = filtered.filter(product => 
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        product.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    switch (priceRange) {
      case 'under25':
        filtered = filtered.filter(product => product.price < 25);
        break;
      case '25to50':
        filtered = filtered.filter(product => product.price >= 25 && product.price <= 50);
        break;
      case 'over50':
        filtered = filtered.filter(product => product.price > 50);
        break;
      default:
        break;
    }

    switch (sortBy) {
      case 'priceLow':
        filtered.sort((a, b) => a.price - b.price);
        break;
      case 'priceHigh':
        filtered.sort((a, b) => b.price - a.price);
        break;
      case 'name':
        filtered.sort((a, b) => a.name.localeCompare(b.name));
        break;
      default:
        break;
    }

    return filtered;
  }, [selectedCategory, selectedSubcategory, searchTerm, priceRange, sortBy]);

  return (
    <>
      <Helmet>
        <title>Shop Premium Vapes, THCA & Smoking Accessories | Sunshine Smoke Shop</title>
        <meta name="description" content="Browse our selection of premium vapes, THCA products, edibles, and smoking accessories. Quality products with fast delivery in Orlando & Kissimmee." />
        <meta name="keywords" content="vape shop Orlando, THCA products Kissimmee, smoke shop near Disney World, CBD store International Drive, Delta-8 Universal Studios" />
      </Helmet>

      <SearchFollowUpPopup
        isOpen={showFollowUp}
        onClose={() => setShowFollowUp(false)}
        searchTerm={lastSearchTerm}
        nearestLocation={nearestLocation}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Shop Our Products</h1>
          <p className="text-xl text-gray-600">
            Premium vapes, THCA products, and smoking accessories
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <input
                type="text"
                placeholder="Search products..."
                className="w-full px-4 py-2 border rounded-lg"
                value={searchTerm}
                onChange={handleSearchChange}
              />
            </div>
            <select
              className="w-full px-4 py-2 border rounded-lg"
              value={priceRange}
              onChange={(e) => setPriceRange(e.target.value)}
            >
              <option value="all">All Prices</option>
              <option value="under25">Under $25</option>
              <option value="25to50">$25 - $50</option>
              <option value="over50">Over $50</option>
            </select>
            <select
              className="w-full px-4 py-2 border rounded-lg"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
            >
              <option value="featured">Featured</option>
              <option value="priceLow">Price: Low to High</option>
              <option value="priceHigh">Price: High to Low</option>
              <option value="name">Name: A to Z</option>
            </select>
          </div>
        </div>

        <div className="flex overflow-x-auto gap-2 mb-8 pb-2">
          <button
            onClick={() => {
              setSelectedCategory('All');
              setSelectedSubcategory('All');
            }}
            className={`px-4 py-2 rounded-full whitespace-nowrap ${
              selectedCategory === 'All'
                ? 'bg-herb text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            All Products
          </button>
          {Object.entries(categories).map(([category, data]) => (
            <button
              key={category}
              onClick={() => {
                setSelectedCategory(category);
                setSelectedSubcategory('All');
              }}
              className={`px-4 py-2 rounded-full whitespace-nowrap ${
                selectedCategory === category
                  ? 'bg-herb text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              {data.icon} {category}
            </button>
          ))}
        </div>

        {selectedCategory !== 'All' && (
          <div className="flex overflow-x-auto gap-2 mb-8 pb-2">
            <button
              onClick={() => setSelectedSubcategory('All')}
              className={`px-4 py-2 rounded-full whitespace-nowrap ${
                selectedSubcategory === 'All'
                  ? 'bg-herb text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              All {selectedCategory}
            </button>
            {categories[selectedCategory].subcategories.map((subcategory) => (
              <button
                key={subcategory}
                onClick={() => setSelectedSubcategory(subcategory)}
                className={`px-4 py-2 rounded-full whitespace-nowrap ${
                  selectedSubcategory === subcategory
                    ? 'bg-herb text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                {subcategory}
              </button>
            ))}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500">No products found matching your criteria.</p>
          </div>
        )}
      </div>
    </>
  );
}