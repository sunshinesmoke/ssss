import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';

export default function VapeGuide() {
  return (
    <>
      <Helmet>
        <title>What's Really in Your Vape? | Understanding Vape Ingredients | Sunshine Smoke Shop</title>
        <meta name="description" content="Learn about vape ingredients, potential risks, and how to choose safe vaping products. Expert guide from Sunshine Smoke Shop in Orlando & Kissimmee." />
        <meta name="keywords" content="vape ingredients, e-liquid safety, vape chemicals, safe vaping, vape shop Orlando, vape store Kissimmee" />
      </Helmet>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <motion.article
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="prose prose-lg max-w-none"
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-6">
            What's Really in Your Vape?
          </h1>

          <div className="bg-primary-50 border border-primary-100 rounded-xl p-6 mb-8">
            <p className="text-gray-800">
              At Sunshine Smoke, we believe in transparency and education when it comes to vaping. If you're using THCA vapes, disposable pens, or e-liquids, it's important to understand what's inside and how it affects you.
            </p>
          </div>

          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">What's in Vape E-Liquid?</h2>
            <div className="bg-white rounded-lg shadow-md p-6">
              <p className="text-gray-700">
                Most e-juices contain a mix of nicotine, propylene glycol, flavoring, and other chemicals. Even products labeled as nicotine-free have been found to contain trace amounts of nicotine. When heated, these ingredients can break down into harmful toxins.
              </p>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Common Ingredients & Their Risks</h2>
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="space-y-4">
                {[
                  { name: 'Nicotine', desc: 'Highly addictive and harmful to adolescent brain development.' },
                  { name: 'Propylene Glycol', desc: 'A common food additive, but also found in antifreeze, paint solvent, and artificial fog machines.' },
                  { name: 'Carcinogens', desc: 'Acetaldehyde & formaldehyde, both linked to cancer risks.' },
                  { name: 'Acrolein', desc: 'A weed-killer chemical that can cause lung damage.' },
                  { name: 'Diacetyl', desc: 'Linked to "popcorn lung", a serious lung disease.' },
                  { name: 'Diethylene Glycol', desc: 'A toxic antifreeze chemical associated with lung disease.' },
                  { name: 'Heavy Metals', desc: 'Nickel, tin, lead, all of which can be inhaled deep into the lungs.' },
                  { name: 'Cadmium', desc: 'A toxic metal found in traditional cigarettes, causing breathing issues.' },
                  { name: 'Benzene', desc: 'A volatile organic compound (VOC) found in car exhaust fumes.' },
                  { name: 'Ultrafine Particles', desc: 'Can be inhaled deep into the lungs, posing long-term respiratory risks.' }
                ].map((item, index) => (
                  <div key={index} className="flex items-start">
                    <span className="text-red-500 mr-2">🚨</span>
                    <div>
                      <span className="font-semibold">{item.name}</span>
                      <span className="text-gray-700"> – {item.desc}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Why Lab Testing Matters</h2>
            <div className="bg-white rounded-lg shadow-md p-6">
              <p className="text-gray-700">
                Since the FDA does not regulate e-cigarettes, the ingredients and effects of different vape products can vary significantly. At SunshineSmoke.com, we prioritize safety and quality, ensuring that our THCA vapes and smoking products meet strict lab-testing standards for purity and potency.
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Shop with Confidence at SunshineSmoke.com</h2>
            <div className="bg-white rounded-lg shadow-md p-6">
              <ul className="list-none space-y-3">
                <li className="flex items-center text-gray-700">
                  <span className="text-green-500 mr-2">✅</span>
                  Lab-tested THCA vapes & cartridges
                </li>
                <li className="flex items-center text-gray-700">
                  <span className="text-green-500 mr-2">✅</span>
                  High-quality ingredients with full transparency
                </li>
                <li className="flex items-center text-gray-700">
                  <span className="text-green-500 mr-2">✅</span>
                  Fast delivery in Orlando, Kissimmee & Disney areas
                </li>
              </ul>
              
              <div className="mt-8 bg-primary-50 border border-primary-100 rounded-lg p-4">
                <p className="text-primary-800 font-medium">
                  Make an informed choice—visit SunshineSmoke.com today for premium, lab-tested THCA and vaping products! 🚀💨
                </p>
              </div>
            </div>
          </section>
        </motion.article>
      </div>
    </>
  );
}