import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const questions = [
  {
    id: 1,
    question: "What type of product are you interested in?",
    options: [
      { id: 'vapes', text: 'Vapes & Cartridges' },
      { id: 'flower', text: 'THCA Flower' },
      { id: 'edibles', text: 'Edibles & Gummies' },
      { id: 'concentrates', text: 'Concentrates & Extracts' }
    ]
  },
  {
    id: 2,
    question: "What's your experience level?",
    options: [
      { id: 'beginner', text: 'Beginner - New to these products' },
      { id: 'intermediate', text: 'Intermediate - Some experience' },
      { id: 'advanced', text: 'Advanced - Regular user' },
      { id: 'expert', text: 'Expert - Connoisseur' }
    ]
  },
  {
    id: 3,
    question: "What effects are you looking for?",
    options: [
      { id: 'relax', text: 'Relaxation & Stress Relief' },
      { id: 'energy', text: 'Energy & Focus' },
      { id: 'sleep', text: 'Sleep Aid' },
      { id: 'pain', text: 'Pain Relief' }
    ]
  },
  {
    id: 4,
    question: "What's your preferred price range?",
    options: [
      { id: 'budget', text: 'Under $30' },
      { id: 'mid', text: '$30 - $50' },
      { id: 'premium', text: '$50 - $100' },
      { id: 'luxury', text: '$100+' }
    ]
  }
];

const recommendations = {
  'vapes-beginner-relax-budget': {
    title: 'Beginner Vape Bundle',
    products: [
      {
        name: 'THCA Disposable Vape',
        description: 'Easy-to-use disposable with relaxing effects',
        price: 29.99
      }
    ]
  },
  'flower-intermediate-energy-mid': {
    title: 'Premium THCA Flower Pack',
    products: [
      {
        name: 'Sativa THCA Flower',
        description: 'Energizing strain with uplifting effects',
        price: 39.99
      }
    ]
  },
  // Add more recommendation combinations as needed
};

export default function ProductQuiz() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [showResults, setShowResults] = useState(false);

  const handleAnswer = (answerId) => {
    setAnswers({ ...answers, [questions[currentQuestion].id]: answerId });
    
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setShowResults(true);
    }
  };

  const getRecommendation = () => {
    const key = `${answers[1]}-${answers[2]}-${answers[3]}-${answers[4]}`;
    return recommendations[key] || {
      title: 'Personalized Recommendation',
      products: [
        {
          name: 'Premium THCA Product',
          description: 'Based on your preferences',
          price: 39.99
        }
      ]
    };
  };

  return (
    <>
      <Helmet>
        <title>Find Your Perfect Product | Sunshine Smoke Shop Quiz</title>
        <meta name="description" content="Take our quiz to find the perfect THCA, vape, or CBD product for you. Expert recommendations from Orlando's premier smoke shop." />
        <meta name="keywords" content="smoke shop quiz Orlando, vape recommendation Kissimmee, THCA product finder, CBD quiz near Disney World" />
      </Helmet>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-lg shadow-xl p-8">
          {!showResults ? (
            <>
              <div className="mb-8">
                <div className="flex justify-between items-center mb-4">
                  <h1 className="text-2xl font-bold text-gray-900">
                    Find Your Perfect Product
                  </h1>
                  <span className="text-sm text-gray-500">
                    Question {currentQuestion + 1} of {questions.length}
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <motion.div
                    className="bg-herb h-2 rounded-full"
                    initial={{ width: 0 }}
                    animate={{
                      width: `${((currentQuestion + 1) / questions.length) * 100}%`
                    }}
                    transition={{ duration: 0.5 }}
                  />
                </div>
              </div>

              <motion.div
                key={currentQuestion}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                <h2 className="text-xl font-semibold text-gray-900 mb-6">
                  {questions[currentQuestion].question}
                </h2>
                <div className="space-y-4">
                  {questions[currentQuestion].options.map((option) => (
                    <motion.button
                      key={option.id}
                      onClick={() => handleAnswer(option.id)}
                      className="w-full text-left px-6 py-4 border-2 border-gray-200 rounded-lg hover:border-herb hover:bg-herb-light hover:bg-opacity-5 transition-colors"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      {option.text}
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            </>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                Your Personalized Recommendations
              </h2>
              <div className="space-y-6 mb-8">
                {getRecommendation().products.map((product, index) => (
                  <div
                    key={index}
                    className="border-2 border-gray-200 rounded-lg p-6"
                  >
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      {product.name}
                    </h3>
                    <p className="text-gray-600 mb-4">{product.description}</p>
                    <p className="text-lg font-bold text-herb">
                      ${product.price}
                    </p>
                  </div>
                ))}
              </div>
              <div className="flex justify-between">
                <button
                  onClick={() => {
                    setCurrentQuestion(0);
                    setAnswers({});
                    setShowResults(false);
                  }}
                  className="px-6 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
                >
                  Start Over
                </button>
                <Link
                  to="/products"
                  className="px-6 py-3 bg-herb text-white rounded-lg hover:bg-herb-dark transition-colors"
                >
                  Shop All Products
                </Link>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </>
  );
}