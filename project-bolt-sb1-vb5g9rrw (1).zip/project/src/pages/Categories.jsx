import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const categories = {
  "Disposable Vapes": {
    icon: "💨",
    subcategories: [
      { name: "Nicotine Disposables", link: "/nicotine-disposables" },
      { name: "THCA Disposables", link: "/thca-disposables" },
      { name: "THC Disposables", link: "/thc-disposables" },
      { name: "Delta-8 Disposables", link: "/delta-8-disposables" },
      { name: "HHC Disposables", link: "/hhc-disposables" }
    ],
    description: "Premium disposable vapes with various options for every preference."
  },
  "Vape Cartridges & Devices": {
    icon: "🔋",
    subcategories: [
      { name: "510 Thread Cartridges", link: "/510-cartridges" },
      { name: "THC Vape Carts", link: "/thc-carts" },
      { name: "Delta-8 Vape Carts", link: "/delta-8-carts" },
      { name: "THCA Live Resin Carts", link: "/thca-carts" },
      { name: "Vape Batteries & Mods", link: "/vape-batteries" }
    ],
    description: "High-quality cartridges and reliable vaping devices."
  },
  "Flower & Pre-Rolls": {
    icon: "🌿",
    subcategories: [
      { name: "THCA Flower", link: "/thca-flower" },
      { name: "THC Flower", link: "/thc-flower" },
      { name: "Delta-8 Flower", link: "/delta-8-flower" },
      { name: "Pre-Rolled Joints", link: "/pre-rolls" }
    ],
    description: "Premium flower and expertly rolled pre-rolls."
  },
  "Edibles & Gummies": {
    icon: "🍬",
    subcategories: [
      { name: "THC Gummies", link: "/thc-gummies" },
      { name: "Delta-8 Gummies", link: "/delta-8-gummies" },
      { name: "THCA Edibles", link: "/thca-edibles" },
      { name: "CBD Edibles", link: "/cbd-edibles" }
    ],
    description: "Delicious edibles with precise dosing."
  },
  "Concentrates & Extracts": {
    icon: "💎",
    subcategories: [
      { name: "THC Wax & Shatter", link: "/thc-concentrates" },
      { name: "Live Resin & Rosin", link: "/live-resin" },
      { name: "THCA Diamonds", link: "/thca-diamonds" }
    ],
    description: "Pure and potent concentrates for experienced users."
  },
  "Smoking Accessories": {
    icon: "🔧",
    subcategories: [
      { name: "Rolling Papers & Wraps", link: "/rolling-papers" },
      { name: "Grinders & Rolling Trays", link: "/grinders" },
      { name: "Lighters & Torches", link: "/lighters" },
      { name: "Bongs & Glass Pipes", link: "/glass" },
      { name: "Dab Rigs & Tools", link: "/dab-rigs" }
    ],
    description: "Essential accessories for the perfect smoking experience."
  },
  "Cigars & Tobacco": {
    icon: "🌴",
    subcategories: [
      { name: "Premium Cigars", link: "/cigars" },
      { name: "Cigar Accessories", link: "/cigar-accessories" },
      { name: "Hookah & Shisha", link: "/hookah" }
    ],
    description: "Fine cigars and premium tobacco products."
  }
};

const featuredCollections = [
  {
    name: "New Arrivals",
    description: "Latest products and exclusive drops",
    link: "/new-arrivals",
    icon: "🆕"
  },
  {
    name: "Best Sellers",
    description: "Our most popular products",
    link: "/best-sellers",
    icon: "⭐"
  },
  {
    name: "Deals & Bundles",
    description: "Special offers and value packs",
    link: "/deals",
    icon: "🎁"
  }
];

export default function Categories() {
  return (
    <>
      <Helmet>
        <title>Shop by Category | Sunshine Smoke Shop Orlando</title>
        <meta name="description" content="Browse our complete selection of vapes, THCA products, edibles, and smoking accessories. Quality products with fast delivery in Orlando & Kissimmee." />
        <meta name="keywords" content="vape shop Orlando, THCA products Kissimmee, smoke shop categories, CBD store Disney area, Delta-8 Universal Studios" />
      </Helmet>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Shop by Category</h1>
          <p className="text-xl text-gray-600">
            Explore our wide selection of premium products
          </p>
        </div>

        {/* Featured Collections */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {featuredCollections.map((collection, index) => (
            <motion.div
              key={collection.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-gradient-to-r from-herb-dark to-herb text-white rounded-lg p-6"
            >
              <div className="text-3xl mb-3">{collection.icon}</div>
              <h2 className="text-xl font-bold mb-2">{collection.name}</h2>
              <p className="text-herb-light mb-4">{collection.description}</p>
              <Link
                to={collection.link}
                className="inline-block bg-white text-herb-dark px-4 py-2 rounded-lg hover:bg-gray-100 transition-colors"
              >
                Shop Now
              </Link>
            </motion.div>
          ))}
        </div>

        {/* Main Categories */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {Object.entries(categories).map(([name, category], index) => (
            <motion.div
              key={name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow"
            >
              <div className="text-3xl mb-4">{category.icon}</div>
              <h2 className="text-xl font-bold text-gray-900 mb-2">{name}</h2>
              <p className="text-gray-600 mb-4">{category.description}</p>
              <ul className="space-y-2">
                {category.subcategories.map((sub) => (
                  <li key={sub.name}>
                    <Link
                      to={sub.link}
                      className="text-herb hover:text-herb-dark transition-colors"
                    >
                      {sub.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        {/* SEO Content */}
        <div className="mt-16 bg-white rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Why Shop with Us?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Quality Products</h3>
              <ul className="space-y-2 text-gray-600">
                <li>✓ Lab-tested for purity</li>
                <li>✓ Premium brands</li>
                <li>✓ Authentic products</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Fast Delivery</h3>
              <ul className="space-y-2 text-gray-600">
                <li>✓ Same-day delivery</li>
                <li>✓ Orlando & Kissimmee area</li>
                <li>✓ Disney World & Universal</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Expert Service</h3>
              <ul className="space-y-2 text-gray-600">
                <li>✓ Knowledgeable staff</li>
                <li>✓ Product guidance</li>
                <li>✓ Multiple locations</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}