import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';

const products = [
  {
    id: 'edible-1',
    name: "Delta-8 THC Gummies",
    description: "Premium Delta-8 THC gummies with 25mg per piece. Available in mixed fruit flavors. Lab tested for purity and potency.",
    price: 29.99,
    category: "Edibles",
    strength: "25mg per piece",
    count: "20 pieces per pack",
    effects: "Relaxing, Uplifting, Stress Relief",
    flavors: "Mixed Fruit"
  },
  {
    id: 'edible-2',
    name: "CBD Sleep Gummies",
    description: "CBD gummies with melatonin for enhanced sleep support. 25mg CBD + 5mg melatonin per piece.",
    price: 34.99,
    category: "Edibles",
    strength: "25mg CBD + 5mg Melatonin",
    count: "30 pieces per pack",
    effects: "Sleep Aid, Relaxation",
    flavors: "Berry"
  },
  {
    id: 'edible-3',
    name: "THCA + CBD Chocolate Bar",
    description: "Premium dark chocolate infused with THCA and CBD. Perfect balance for optimal effects.",
    price: 24.99,
    category: "Edibles",
    strength: "100mg THCA + 100mg CBD",
    count: "10 pieces per bar",
    effects: "Balanced, Calming",
    flavors: "Dark Chocolate"
  },
  {
    id: 'edible-4',
    name: "Delta-8 Hard Candies",
    description: "Long-lasting Delta-8 THC hard candies. Perfect for discrete consumption.",
    price: 19.99,
    category: "Edibles",
    strength: "10mg per piece",
    count: "20 pieces per pack",
    effects: "Mild Euphoria, Focus",
    flavors: "Watermelon, Cherry, Lemon"
  },
  {
    id: 'edible-5',
    name: "Full Spectrum CBD Gummies",
    description: "Full spectrum CBD gummies with natural terpenes. Enhanced entourage effect.",
    price: 39.99,
    category: "Edibles",
    strength: "50mg per piece",
    count: "30 pieces per pack",
    effects: "Pain Relief, Anxiety Relief",
    flavors: "Tropical Mix"
  }
];

export default function Edibles() {
  return (
    <>
      <Helmet>
        <title>Premium CBD & Delta-8 Edibles | Sunshine Smoke Shop Orlando</title>
        <meta name="description" content="Shop premium CBD and Delta-8 edibles in Orlando & Kissimmee. Quality gummies, chocolates, and candies. Lab-tested for purity. Fast delivery near Disney World." />
        <meta name="keywords" content="CBD gummies Orlando, Delta-8 edibles Kissimmee, THC gummies Disney area, CBD chocolate Universal Studios, edibles International Drive, hemp gummies Florida" />
      </Helmet>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Premium CBD & Delta-8 Edibles</h1>
          <p className="text-xl text-gray-600">
            Lab-tested, delicious edibles available for delivery in Orlando & Kissimmee
          </p>
        </div>

        <div className="bg-herb-light bg-opacity-5 rounded-lg p-6 mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Why Choose Our Edibles?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                title: "Lab Tested",
                description: "All products third-party tested for purity and potency",
                icon: "🔬"
              },
              {
                title: "Premium Quality",
                description: "Made with high-quality ingredients and precise dosing",
                icon: "⭐"
              },
              {
                title: "Fast Delivery",
                description: "Same-day delivery in Orlando & Kissimmee area",
                icon: "🚚"
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-lg p-6"
              >
                <div className="text-3xl mb-3">{feature.icon}</div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {products.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-lg shadow-lg p-6"
            >
              <div className="mb-4">
                <span className="inline-block bg-herb-light bg-opacity-10 text-herb-dark px-3 py-1 rounded-full text-sm font-medium">
                  {product.category}
                </span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{product.name}</h3>
              <p className="text-gray-600 mb-4">{product.description}</p>
              <div className="space-y-2 mb-4">
                <p className="text-gray-700">
                  <span className="font-semibold">Strength:</span> {product.strength}
                </p>
                <p className="text-gray-700">
                  <span className="font-semibold">Count:</span> {product.count}
                </p>
                <p className="text-gray-700">
                  <span className="font-semibold">Effects:</span> {product.effects}
                </p>
                <p className="text-gray-700">
                  <span className="font-semibold">Flavors:</span> {product.flavors}
                </p>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-2xl font-bold text-gray-900">${product.price}</span>
                <button className="bg-herb hover:bg-herb-dark text-white px-6 py-2 rounded-lg transition-colors">
                  Add to Cart
                </button>
              </div>
            </motion.div>
          ))}
        </motion.div>

        <div className="mt-16 bg-white rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Frequently Asked Questions</h2>
          <div className="space-y-6">
            {[
              {
                question: "What are Delta-8 edibles?",
                answer: "Delta-8 THC edibles are hemp-derived products that offer mild psychoactive effects. They're legal under the 2018 Farm Bill and provide a more gentle experience compared to traditional THC products."
              },
              {
                question: "How long do edibles take to work?",
                answer: "Effects typically begin within 30-60 minutes and can last 4-6 hours. We recommend starting with a low dose and waiting at least 2 hours before consuming more."
              },
              {
                question: "Are your edibles lab tested?",
                answer: "Yes! All our edibles undergo rigorous third-party lab testing for potency and purity. Lab reports are available upon request."
              }
            ].map((faq, index) => (
              <div key={index}>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{faq.question}</h3>
                <p className="text-gray-600">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}