import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

export default function Cigars() {
  return (
    <>
      <Helmet>
        <title>Premium Cigars Guide & Selection | Sunshine Smoke Shop Orlando</title>
        <meta name="description" content="Explore our premium cigar selection and learn about cigar history, proper smoking techniques, and pricing. Visit Sunshine Smoke Shop in Orlando & Kissimmee for quality cigars." />
        <meta name="keywords" content="premium cigars Orlando, cigar shop Kissimmee, Cuban cigars Disney World area, cigar humidor International Drive, tobacco shop Universal Studios, cigar accessories Florida" />
      </Helmet>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <motion.article
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="prose prose-lg max-w-none"
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-6">
            About Cigars: History, Smoking Guide & Cost
          </h1>

          <div className="bg-primary-50 border border-primary-100 rounded-xl p-6 mb-8">
            <p className="text-gray-800">
              Discover the world of premium cigars at Sunshine Smoke Shop. From Cuban-style classics to modern blends, we offer a carefully curated selection for both newcomers and aficionados.
            </p>
          </div>

          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">The Origins of Cigars</h2>
            <div className="bg-white rounded-lg shadow-md p-6">
              <p className="text-gray-700 mb-4">
                Cigars have a rich history dating back centuries, originating from indigenous cultures in the Americas. The earliest records of cigar smoking come from the Mayans, who wrapped tobacco in palm or plantain leaves.
              </p>
              <p className="text-gray-700 mb-4">
                When Christopher Columbus and his crew arrived in the New World in 1492, they encountered natives smoking rolled tobacco, which soon spread to Europe. Over time, Cuba became synonymous with high-quality cigars, thanks to its ideal climate and expert craftsmanship.
              </p>
              <p className="text-gray-700">
                Today, cigars are produced worldwide, with notable regions including the Dominican Republic, Nicaragua, and Honduras.
              </p>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">How to Properly Smoke a Cigar</h2>
            <div className="bg-white rounded-lg shadow-md p-6">
              <p className="text-gray-700 mb-4">
                Smoking a cigar is an art that requires patience and technique. Here's a step-by-step guide to ensure the best experience:
              </p>
              <div className="space-y-4">
                <div className="flex items-start">
                  <span className="text-primary-600 font-bold mr-2">1.</span>
                  <div>
                    <h3 className="font-semibold text-gray-900">Choose the Right Cigar</h3>
                    <p className="text-gray-700">Select a cigar that matches your preference in size, strength, and flavor.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <span className="text-primary-600 font-bold mr-2">2.</span>
                  <div>
                    <h3 className="font-semibold text-gray-900">Cut the Cigar</h3>
                    <p className="text-gray-700">Use a quality cigar cutter to snip the cap without damaging the wrapper.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <span className="text-primary-600 font-bold mr-2">3.</span>
                  <div>
                    <h3 className="font-semibold text-gray-900">Toast the Foot</h3>
                    <p className="text-gray-700">Before lighting, gently toast the end of the cigar with a butane lighter or wooden match to warm the tobacco.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <span className="text-primary-600 font-bold mr-2">4.</span>
                  <div>
                    <h3 className="font-semibold text-gray-900">Light Evenly</h3>
                    <p className="text-gray-700">Hold the flame slightly away from the cigar while rotating it to ensure an even burn.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <span className="text-primary-600 font-bold mr-2">5.</span>
                  <div>
                    <h3 className="font-semibold text-gray-900">Draw Slowly</h3>
                    <p className="text-gray-700">Take slow, steady puffs without inhaling; cigars are meant to be savored.</p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">The Cost of Cigars</h2>
            <div className="bg-white rounded-lg shadow-md p-6">
              <p className="text-gray-700 mb-4">
                The price of cigars varies widely depending on the brand, quality, and country of origin:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>Budget-friendly cigars: Starting at $2 per stick</li>
                <li>Premium hand-rolled cigars: $15-50 per stick</li>
                <li>Limited-edition and aged cigars: $100+ per stick</li>
                <li>Rare collector's cigars: $500+ per stick</li>
              </ul>
              <p className="text-gray-700 mt-4">
                Factors such as tobacco quality, aging process, and craftsmanship influence the final price.
              </p>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Choosing the Best Cigar for You</h2>
            <div className="bg-white rounded-lg shadow-md p-6">
              <p className="text-gray-700 mb-4">
                With so many options, finding the perfect cigar depends on personal taste. Beginners may prefer mild cigars with a smooth flavor profile, while seasoned smokers might enjoy full-bodied options with complex notes.
              </p>
              <div className="bg-primary-50 border border-primary-100 rounded-lg p-4 mt-6">
                <h3 className="font-semibold text-gray-900 mb-2">Visit Our Stores</h3>
                <p className="text-gray-700">
                  Explore our premium cigar selection at any of our locations in Orlando and Kissimmee. Our knowledgeable staff can help you find the perfect cigar for your taste and experience level.
                </p>
                <div className="mt-4">
                  <Link
                    to="/contact"
                    className="inline-flex items-center text-primary-600 hover:text-primary-800"
                  >
                    Find a Store Near You →
                  </Link>
                </div>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Final Thoughts</h2>
            <div className="bg-white rounded-lg shadow-md p-6">
              <p className="text-gray-700 mb-4">
                Cigars offer more than just a smoking experience—they represent tradition, craftsmanship, and relaxation. Whether you're a novice or an aficionado, understanding the origins, proper smoking techniques, and pricing can enhance your appreciation of fine cigars.
              </p>
              <div className="bg-primary-50 border border-primary-100 rounded-lg p-4">
                <p className="text-primary-800 font-medium">
                  Visit Sunshine Smoke Shop today for premium cigars and expert advice! Call (407) 778-1326 for availability.
                </p>
              </div>
            </div>
          </section>
        </motion.article>
      </div>
    </>
  );
}