import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { useNavigate, Link } from 'react-router-dom';
import useCartStore from '../../store/cartStore';
import toast from 'react-hot-toast';

export default function ChocolateCookies() {
  const navigate = useNavigate();
  const addToCart = useCartStore(state => state.addItem);
  const [quantity, setQuantity] = React.useState(1);

  const product = {
    id: 'magic-chocolate-cookies',
    name: "Magic Belgian Chocolate Cookies",
    price: 29.99,
    description: "Premium Belgian chocolate cookies infused with high-quality ingredients. Each cookie is precisely dosed and lab-tested for consistency and quality.",
    details: {
      flavor: "Rich Belgian Chocolate",
      size: "10 cookies per pack",
      ingredients: "Premium Belgian chocolate, Natural cocoa, Organic flour, Pure cane sugar",
      effects: "Relaxing, Euphoric, Uplifting",
      dosage: "25mg per cookie",
      totalContent: "250mg per pack"
    }
  };

  const handleAddToCart = () => {
    addToCart({
      ...product,
      quantity
    });
    toast.success('Added to cart!');
  };

  return (
    <>
      <Helmet>
        <title>Buy Magic Belgian Chocolate Cookies | Sunshine Smoke Shop Orlando</title>
        <meta name="description" content="Premium Belgian chocolate cookies available at Sunshine Smoke Shop. Fast delivery in Orlando, Kissimmee, and near Disney World. Visit our stores on International Drive & Lake Buena Vista." />
        <meta name="keywords" content="edibles Orlando, chocolate cookies Kissimmee, smoke shop near Disney World, CBD edibles International Drive, edible delivery Lake Buena Vista" />
        <link rel="canonical" href="https://sunshinesmoke.com/products/magic-chocolate-cookies" />
        
        {/* Local Business Schema */}
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Product",
            "name": "Magic Belgian Chocolate Cookies",
            "description": "Premium Belgian chocolate cookies infused with high-quality ingredients",
            "brand": {
              "@type": "Brand",
              "name": "Sunshine Smoke Shop"
            },
            "offers": {
              "@type": "Offer",
              "price": "29.99",
              "priceCurrency": "USD",
              "availability": "https://schema.org/InStock"
            },
            "seller": {
              "@type": "Store",
              "name": "Sunshine Smoke Shop",
              "telephone": "(321) 440-4191",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "8216 World Center Drive, Suite D",
                "addressLocality": "Orlando",
                "addressRegion": "FL",
                "postalCode": "32821",
                "addressCountry": "US"
              }
            }
          })}
        </script>
      </Helmet>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Breadcrumbs for SEO */}
        <nav className="text-sm mb-6">
          <ol className="list-none p-0 inline-flex">
            <li className="flex items-center">
              <Link to="/" className="text-gray-500 hover:text-herb">Home</Link>
              <span className="mx-2 text-gray-500">/</span>
            </li>
            <li className="flex items-center">
              <Link to="/products" className="text-gray-500 hover:text-herb">Products</Link>
              <span className="mx-2 text-gray-500">/</span>
            </li>
            <li className="text-gray-700">Magic Belgian Chocolate Cookies</li>
          </ol>
        </nav>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-lg shadow-lg overflow-hidden"
        >
          <div className="p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Product Info */}
              <div>
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                  Magic Belgian Chocolate Cookies | Orlando's Premium Edibles
                </h1>
                <div className="mb-6">
                  <span className="text-2xl font-bold text-herb">${product.price}</span>
                  <span className="ml-2 text-gray-600">| Free Delivery in Orlando & Kissimmee</span>
                </div>
                <div className="prose prose-lg mb-6">
                  <p className="text-gray-600">{product.description}</p>
                </div>

                {/* Product Details */}
                <div className="space-y-4 mb-8">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900 mb-4">Product Specifications</h2>
                    <ul className="space-y-2">
                      <li className="flex items-center text-gray-600">
                        <span className="font-medium mr-2">Flavor:</span>
                        {product.details.flavor}
                      </li>
                      <li className="flex items-center text-gray-600">
                        <span className="font-medium mr-2">Size:</span>
                        {product.details.size}
                      </li>
                      <li className="flex items-center text-gray-600">
                        <span className="font-medium mr-2">Dosage:</span>
                        {product.details.dosage}
                      </li>
                      <li className="flex items-center text-gray-600">
                        <span className="font-medium mr-2">Total Content:</span>
                        {product.details.totalContent}
                      </li>
                    </ul>
                  </div>

                  <div>
                    <h2 className="text-2xl font-bold text-gray-900 mb-4">Effects & Benefits</h2>
                    <p className="text-gray-600">{product.details.effects}</p>
                  </div>

                  <div>
                    <h2 className="text-2xl font-bold text-gray-900 mb-4">Premium Ingredients</h2>
                    <p className="text-gray-600">{product.details.ingredients}</p>
                  </div>
                </div>

                {/* Add to Cart */}
                <div className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <label htmlFor="quantity" className="text-gray-700 font-medium">
                      Quantity:
                    </label>
                    <select
                      id="quantity"
                      value={quantity}
                      onChange={(e) => setQuantity(Number(e.target.value))}
                      className="rounded-md border-gray-300 shadow-sm focus:border-herb focus:ring-herb"
                    >
                      {[1, 2, 3, 4, 5].map((num) => (
                        <option key={num} value={num}>
                          {num}
                        </option>
                      ))}
                    </select>
                  </div>

                  <button
                    onClick={handleAddToCart}
                    className="w-full bg-herb text-white py-3 px-6 rounded-lg hover:bg-herb-dark transition-colors"
                  >
                    Add to Cart - ${(product.price * quantity).toFixed(2)}
                  </button>
                </div>
              </div>

              {/* Product Features */}
              <div className="space-y-6">
                <div className="bg-herb-light bg-opacity-10 rounded-lg p-6">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">Premium Quality Features</h2>
                  <ul className="space-y-3">
                    <li className="flex items-center text-gray-600">
                      <span className="text-herb mr-2">✓</span>
                      Premium Belgian chocolate from Orlando's top smoke shop
                    </li>
                    <li className="flex items-center text-gray-600">
                      <span className="text-herb mr-2">✓</span>
                      Lab-tested for quality and consistency
                    </li>
                    <li className="flex items-center text-gray-600">
                      <span className="text-herb mr-2">✓</span>
                      Precise dosing for optimal effects
                    </li>
                    <li className="flex items-center text-gray-600">
                      <span className="text-herb mr-2">✓</span>
                      All-natural ingredients, locally available
                    </li>
                  </ul>
                </div>

                <div className="bg-yellow-50 rounded-lg p-6">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">Orlando & Kissimmee Delivery</h2>
                  <ul className="space-y-3">
                    <li className="flex items-center text-gray-600">
                      <span className="text-yellow-500 mr-2">🚚</span>
                      Same-day delivery near Disney World & Universal
                    </li>
                    <li className="flex items-center text-gray-600">
                      <span className="text-yellow-500 mr-2">📍</span>
                      Available at our International Drive location
                    </li>
                    <li className="flex items-center text-gray-600">
                      <span className="text-yellow-500 mr-2">⭐</span>
                      Free delivery on orders over $50
                    </li>
                  </ul>
                </div>

                <div className="bg-gray-50 rounded-lg p-6">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">Visit Our Orlando Locations</h2>
                  <div className="space-y-4">
                    <p className="text-gray-600">
                      <strong>World Center Drive:</strong><br />
                      8216 World Center Drive, Suite D<br />
                      Orlando, FL 32821<br />
                      (321) 440-4191
                    </p>
                    <p className="text-gray-600">
                      <strong>International Drive:</strong><br />
                      Visit our store near Universal Studios<br />
                      Open 24/7 for your convenience
                    </p>
                    <Link to="/contact" className="text-herb hover:text-herb-dark transition-colors">
                      View All Locations →
                    </Link>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-6">
                  <h2 className="text-2xl font-bold text-gray-900 mb-4">Important Notice</h2>
                  <p className="text-gray-600">
                    Must be 21 or older to purchase. Available at Sunshine Smoke Shop locations throughout Orlando and Kissimmee. Keep out of reach of children and pets. Store in a cool, dry place.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </>
  );
}