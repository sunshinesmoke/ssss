import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';

export default function LabReportGuide() {
  return (
    <>
      <Helmet>
        <title>How to Read a THCA Lab Report | Sunshine Smoke Shop</title>
        <meta name="description" content="Learn how to read and understand THCA lab reports and Certificates of Analysis (COA). Quality assurance guide for THCA products from Sunshine Smoke Shop in Orlando & Kissimmee." />
        <meta name="keywords" content="THCA lab report, Certificate of Analysis, COA reading guide, THCA testing, cannabis lab results, smoke shop Orlando, vape shop Kissimmee" />
      </Helmet>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <motion.article
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="prose prose-lg max-w-none"
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-6">
            How to Read a THCA Lab Report
          </h1>

          <div className="bg-primary-50 border border-primary-100 rounded-xl p-6 mb-8">
            <p className="text-gray-800">
              At Sunshine Smoke, we're committed to providing premium THCA products in Orlando, Kissimmee, and the Disney area with complete transparency and quality assurance. Whether you're shopping for THCA flower, vapes, or pre-rolls, it's crucial to check lab reports to ensure purity, potency, and safety.
            </p>
          </div>

          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">What Are THCA Lab Reports?</h2>
            <div className="bg-white rounded-lg shadow-md p-6">
              <p className="text-gray-700">
                A THCA lab report provides detailed information about a product's cannabinoid content, terpene profile, and purity. At Sunshine Smoke, we make our lab results easily accessible so you can trust what you're buying.
              </p>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Why THCA Lab Reports Matter</h2>
            <div className="bg-white rounded-lg shadow-md p-6">
              <p className="text-gray-700 mb-4">
                In the evolving hemp and cannabis industry, third-party lab testing is essential for verifying:
              </p>
              <ul className="list-none space-y-3">
                <li className="flex items-center text-gray-700">
                  <span className="text-green-500 mr-2">✅</span>
                  Total THCA & THC Content (Ensuring legal compliance & potency)
                </li>
                <li className="flex items-center text-gray-700">
                  <span className="text-green-500 mr-2">✅</span>
                  Terpene Profiles (Enhancing flavor & effects)
                </li>
                <li className="flex items-center text-gray-700">
                  <span className="text-green-500 mr-2">✅</span>
                  Pesticide & Contaminant Testing (Ensuring purity & safety)
                </li>
              </ul>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">How to Find THCA Lab Reports for Sunshine Smoke Products</h2>
            <div className="bg-white rounded-lg shadow-md p-6">
              <ul className="list-none space-y-4">
                <li className="flex items-start">
                  <span className="font-bold text-primary-600 mr-2">1️⃣</span>
                  <span className="text-gray-700">On the Product Label – Scan the QR code on your THCA vape, flower, or pre-roll to access its lab report.</span>
                </li>
                <li className="flex items-start">
                  <span className="font-bold text-primary-600 mr-2">2️⃣</span>
                  <span className="text-gray-700">On Our Website – Visit our Lab Reports page or check the product description for a direct COA (Certificate of Analysis) link.</span>
                </li>
              </ul>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Different THCA Products & Their Lab Reports</h2>
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-semibold flex items-center">
                    <span className="mr-2">🌿</span>
                    THCA Flower
                  </h3>
                  <p className="text-gray-700 mt-2">
                    Our premium THCA flower looks, smells, and smokes just like traditional cannabis—except it contains less than 0.3% THC to remain compliant. Lab reports confirm high THCA content and terpene-rich profiles for an exceptional smoking experience.
                  </p>
                </div>
                <div>
                  <h3 className="text-xl font-semibold flex items-center">
                    <span className="mr-2">💨</span>
                    THCA Vapes
                  </h3>
                  <p className="text-gray-700 mt-2">
                    Our THCA disposables and carts are crafted with live resin terpenes for enhanced flavor and effects. Lab reports verify the purity, potency, and absence of harmful additives.
                  </p>
                </div>
                <div>
                  <h3 className="text-xl font-semibold flex items-center">
                    <span className="mr-2">🔥</span>
                    THCA Pre-Rolls
                  </h3>
                  <p className="text-gray-700 mt-2">
                    For convenience, THCA pre-rolls offer a smooth and potent smoking experience. Lab reports ensure high cannabinoid content and no contaminants.
                  </p>
                </div>
              </div>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">How to Read a THCA Lab Report</h2>
            <div className="bg-white rounded-lg shadow-md p-6">
              <p className="text-gray-700 mb-4">
                Understanding a THCA Certificate of Analysis (COA) ensures you're getting top-tier quality:
              </p>
              <ul className="list-disc pl-6 space-y-3 text-gray-700">
                <li>Total Cannabinoids – Shows overall potency of the product.</li>
                <li>THCA Content – Determines strength before decarboxylation (heating).</li>
                <li>Total THC – Must remain below 0.3% for legal compliance.</li>
                <li>Terpene Profile – Identifies the compounds responsible for flavor and effects.</li>
                <li>Contaminant Testing – Screens for pesticides, heavy metals, and solvents.</li>
              </ul>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Shop Sunshine Smoke for Quality THCA in Orlando & Kissimmee</h2>
            <div className="bg-white rounded-lg shadow-md p-6">
              <p className="text-gray-700 mb-4">
                At Sunshine Smoke, we ensure every product meets strict lab-testing standards so you can enjoy safe, legal, and high-quality THCA.
              </p>
              <div className="bg-primary-50 border border-primary-100 rounded-lg p-4">
                <p className="text-primary-800 font-medium flex items-center">
                  <span className="mr-2">✅</span>
                  Visit us in Orlando, Kissimmee, or order online for fast delivery! 🚀💨
                </p>
              </div>
            </div>
          </section>
        </motion.article>
      </div>
    </>
  );
}