import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';

const blogPosts = [
  {
    id: 1,
    title: "24-Hour Vape Shop Guide: Orlando's Best Locations",
    excerpt: "Find the best 24-hour vape shops in Orlando, including locations near Universal Studios, Disney Springs, and International Drive.",
    date: "2024-01-20",
    category: "Locations"
  },
  {
    id: 2,
    title: "Complete Guide to Delta-8 Products Near Theme Parks",
    excerpt: "Everything you need to know about Delta-8 products available near Universal Studios and SeaWorld Orlando.",
    date: "2024-01-15",
    category: "Products"
  },
  {
    id: 3,
    title: "Best Smoke Shops Near Disney Springs",
    excerpt: "Discover top-rated smoke shops around Disney Springs and Lake Buena Vista area, featuring premium products and expert service.",
    date: "2024-01-12",
    category: "Locations"
  },
  {
    id: 4,
    title: "CBD Store Guide: International Drive & Tourist Areas",
    excerpt: "Your comprehensive guide to finding quality CBD products along International Drive and tourist destinations.",
    date: "2024-01-05",
    category: "Guides"
  },
  {
    id: 5,
    title: "Kissimmee Smoke Shop Delivery Services",
    excerpt: "Learn about convenient smoke shop delivery services in Kissimmee and surrounding areas.",
    date: "2024-01-01",
    category: "Services"
  }
];

const relatedResources = [
  {
    title: "THC Products Near SeaWorld Orlando",
    description: "Guide to finding quality THC products in the SeaWorld area"
  },
  {
    title: "Hemp Shop Locations Near Lake Buena Vista",
    description: "Directory of hemp shops around Lake Buena Vista and Disney area"
  },
  {
    title: "CBD Store Guide: International Drive",
    description: "Complete guide to CBD stores along International Drive"
  }
];

export default function Blog() {
  return (
    <>
      <Helmet>
        <title>Smoke Shop & Vape Guide | Orlando & Kissimmee Area</title>
        <meta name="description" content="Find the best 24-hour vape shops in Orlando, Delta-8 dispensaries near Universal Studios, smoke shops near Disney Springs, and CBD stores on International Drive. Complete guide to THC products near SeaWorld Orlando." />
        <meta name="keywords" content="24-hour vape shop Orlando, Delta-8 dispensary Universal Studios, smoke shop Disney Springs, hemp shop Lake Buena Vista, CBD store International Drive, Kissimmee smoke shop delivery, THC products SeaWorld Orlando" />
        <link rel="canonical" href="https://sunshinesmoke.com/blog" />
      </Helmet>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Orlando Smoke Shop Guide</h1>
          <p className="text-lg text-gray-600">Your comprehensive guide to smoke shops, vape stores, and CBD locations in Orlando & Kissimmee</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post) => (
            <motion.article
              key={post.id}
              className="bg-white rounded-lg shadow-lg overflow-hidden"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <span className="inline-block bg-primary-100 text-primary-800 text-sm font-medium px-3 py-1 rounded-full">
                    {post.category}
                  </span>
                  <span className="text-gray-500 text-sm ml-4">
                    {new Date(post.date).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </span>
                </div>
                <h2 className="text-xl font-bold text-gray-900 mb-3">
                  {post.title}
                </h2>
                <p className="text-gray-600 mb-4">
                  {post.excerpt}
                </p>
                <Link
                  to={`/blog/${post.id}`}
                  className="inline-flex items-center text-primary-600 hover:text-primary-800"
                >
                  Read More
                  <svg
                    className="w-4 h-4 ml-2"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M5 12h14M12 5l7 7-7 7" />
                  </svg>
                </Link>
              </div>
            </motion.article>
          ))}
        </div>

        <div className="mt-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Local Resources</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {relatedResources.map((resource, index) => (
              <div
                key={index}
                className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow"
              >
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{resource.title}</h3>
                <p className="text-gray-600">{resource.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}