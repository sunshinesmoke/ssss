import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import ProductCard from '../components/ProductCard';

const products = [
  {
    id: 'thca-1',
    name: "Blueberry Muffin THCA Flower",
    description: "A delightful blend of sweet berry and fresh-baked pastry notes. Premium indoor-grown flower with 27% THCA content. Third-party lab tested for purity.",
    price: 39.99,
    category: "THCA Flower",
    strain: "Indica Dominant",
    thcaContent: "27%",
    effects: "Relaxing, Euphoric, Pain Relief"
  },
  {
    id: 'thca-2',
    name: "Super Sour Space Candy THCA Flower",
    description: "Energizing sativa with intense citrus and diesel notes. Indoor-grown with 25% THCA content. Perfect for daytime use.",
    price: 34.99,
    category: "THCA Flower",
    strain: "Sativa Dominant",
    thcaContent: "25%",
    effects: "Energetic, Creative, Focused"
  },
  {
    id: 'thca-3',
    name: "Wedding Cake THCA Flower",
    description: "Premium hybrid strain featuring sweet vanilla and earthy pepper notes. 29% THCA content with exceptional trichome coverage.",
    price: 44.99,
    category: "THCA Flower",
    strain: "Hybrid",
    thcaContent: "29%",
    effects: "Balanced, Uplifting, Calming"
  },
  {
    id: 'thca-4',
    name: "Northern Lights THCA Flower",
    description: "Classic indica strain with sweet pine and earthy undertones. 26% THCA content. Known for its relaxing properties.",
    price: 39.99,
    category: "THCA Flower",
    strain: "Indica",
    thcaContent: "26%",
    effects: "Relaxing, Sleep Aid, Stress Relief"
  },
  {
    id: 'thca-5',
    name: "Sour Diesel THCA Flower",
    description: "Energizing sativa with classic diesel aroma and citrus notes. 28% THCA content. Perfect for daytime use.",
    price: 42.99,
    category: "THCA Flower",
    strain: "Sativa",
    thcaContent: "28%",
    effects: "Energetic, Uplifting, Creative"
  },
  {
    id: 'thca-6',
    name: "Gelato THCA Flower",
    description: "Premium hybrid featuring sweet berry and cream notes. 30% THCA content. Known for its balanced effects.",
    price: 46.99,
    category: "THCA Flower",
    strain: "Hybrid",
    thcaContent: "30%",
    effects: "Balanced, Euphoric, Creative"
  }
];

export default function ThcaFlower() {
  return (
    <>
      <Helmet>
        <title>Premium THCA Flower | Sunshine Smoke Shop Orlando</title>
        <meta name="description" content="Shop premium THCA flower in Orlando & Kissimmee. High-quality strains including Wedding Cake, Northern Lights, and Sour Diesel. Lab-tested for purity." />
        <meta name="keywords" content="THCA flower Orlando, hemp flower Kissimmee, premium THCA buds, legal hemp flower, smoke shop near Disney World, CBD store International Drive" />
      </Helmet>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Premium THCA Flower</h1>
          <p className="text-xl text-gray-600">
            Lab-tested, premium-grade THCA flower available for delivery in Orlando & Kissimmee
          </p>
        </div>

        <div className="bg-herb-light bg-opacity-5 rounded-lg p-6 mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Why Choose Our THCA Flower?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                title: "Lab Tested",
                description: "All products third-party tested for purity and potency",
                icon: "🔬"
              },
              {
                title: "Premium Quality",
                description: "Indoor-grown, hand-trimmed premium flower",
                icon: "🌿"
              },
              {
                title: "Fast Delivery",
                description: "Same-day delivery in Orlando & Kissimmee area",
                icon: "🚚"
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-lg p-6"
              >
                <div className="text-3xl mb-3">{feature.icon}</div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {products.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-lg shadow-lg p-6"
            >
              <div className="mb-4">
                <span className="inline-block bg-herb-light bg-opacity-10 text-herb-dark px-3 py-1 rounded-full text-sm font-medium">
                  {product.strain}
                </span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{product.name}</h3>
              <p className="text-gray-600 mb-4">{product.description}</p>
              <div className="space-y-2 mb-4">
                <p className="text-gray-700">
                  <span className="font-semibold">THCA Content:</span> {product.thcaContent}
                </p>
                <p className="text-gray-700">
                  <span className="font-semibold">Effects:</span> {product.effects}
                </p>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-2xl font-bold text-gray-900">${product.price}</span>
                <button className="bg-herb hover:bg-herb-dark text-white px-6 py-2 rounded-lg transition-colors">
                  Add to Cart
                </button>
              </div>
            </motion.div>
          ))}
        </motion.div>

        <div className="mt-16 bg-white rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Frequently Asked Questions</h2>
          <div className="space-y-6">
            {[
              {
                question: "What is THCA flower?",
                answer: "THCA flower is hemp flower that contains high levels of THCA (Tetrahydrocannabinolic Acid), the non-psychoactive precursor to THC. All our THCA products are farm bill compliant and lab tested."
              },
              {
                question: "Is THCA flower legal?",
                answer: "Yes, our THCA flower is legal under the 2018 Farm Bill as it contains less than 0.3% Delta-9 THC. All products come with full lab reports confirming compliance."
              },
              {
                question: "Do you offer delivery?",
                answer: "Yes! We offer same-day delivery throughout Orlando and Kissimmee, including areas near Disney World, Universal Studios, and International Drive."
              }
            ].map((faq, index) => (
              <div key={index}>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{faq.question}</h3>
                <p className="text-gray-600">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}