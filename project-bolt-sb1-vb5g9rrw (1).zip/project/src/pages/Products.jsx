import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const categories = {
  "Disposable Vapes": {
    subcategories: [
      "Nicotine Disposables",
      "THCA Disposables",
      "THC Disposables",
      "Delta-8 Disposables",
      "HHC Disposables"
    ],
    products: [
      {
        id: 'vape-1',
        name: "THCA Live Resin Disposable",
        description: "Premium THCA live resin with natural terpenes. 2g capacity with rechargeable battery.",
        price: 39.99,
        strain: "Hybrid",
        effects: "Balanced, Uplifting",
        category: "THCA Disposables"
      },
      // Add more products...
    ]
  },
  "Vape Cartridges & Devices": {
    subcategories: [
      "510 Thread Cartridges",
      "THC Vape Carts",
      "Delta-8 Vape Carts",
      "THCA Live Resin Carts",
      "Vape Batteries & Mods"
    ],
    products: [
      {
        id: 'cart-1',
        name: "THCA Live Resin Cart",
        description: "1g THCA live resin cartridge with full spectrum terpenes. Compatible with 510 thread batteries.",
        price: 34.99,
        strain: "Indica",
        effects: "Relaxing, Pain Relief",
        category: "THCA Live Resin Carts"
      },
      // Add more products...
    ]
  },
  "Flower & Pre-Rolls": {
    subcategories: [
      "THCA Flower",
      "THC Flower",
      "Delta-8 Flower",
      "Pre-Rolled Joints"
    ],
    products: [
      {
        id: 'flower-1',
        name: "Premium THCA Flower",
        description: "Indoor-grown THCA flower with 28% THCA content. Lab tested for purity.",
        price: 29.99,
        strain: "Sativa",
        effects: "Energetic, Creative",
        category: "THCA Flower"
      },
      // Add more products...
    ]
  },
  "Edibles & Gummies": {
    subcategories: [
      "THC Gummies",
      "Delta-8 Gummies",
      "THCA Edibles",
      "CBD Edibles"
    ],
    products: [
      {
        id: 'edible-1',
        name: "Delta-8 Gummies",
        description: "25mg Delta-8 THC per gummy. Mixed fruit flavors. Lab tested for potency.",
        price: 24.99,
        strength: "25mg",
        effects: "Relaxing, Euphoric",
        category: "Delta-8 Gummies"
      },
      // Add more products...
    ]
  },
  "Concentrates & Extracts": {
    subcategories: [
      "THC Wax & Shatter",
      "Live Resin & Rosin",
      "THCA Diamonds"
    ],
    products: [
      {
        id: 'concentrate-1',
        name: "THCA Diamonds",
        description: "99%+ pure THCA crystalline. Perfect for dabbing or adding to flower.",
        price: 49.99,
        purity: "99%+",
        effects: "Potent, Clean",
        category: "THCA Diamonds"
      },
      // Add more products...
    ]
  },
  "Smoking Accessories": {
    subcategories: [
      "Rolling Papers & Wraps",
      "Grinders & Rolling Trays",
      "Lighters & Torches",
      "Bongs & Glass Pipes",
      "Dab Rigs & Tools"
    ],
    products: [
      {
        id: 'acc-1',
        name: "Premium Metal Grinder",
        description: "4-piece aluminum grinder with pollen catcher. Sharp diamond-cut teeth.",
        price: 29.99,
        material: "Aircraft-grade aluminum",
        features: "Pollen catcher, Diamond-cut teeth",
        category: "Grinders & Rolling Trays"
      },
      // Add more products...
    ]
  },
  "Cigars & Tobacco": {
    subcategories: [
      "Premium Cigars",
      "Cigar Accessories",
      "Hookah & Shisha"
    ],
    products: [
      {
        id: 'cigar-1',
        name: "Premium Hand-Rolled Cigar",
        description: "Dominican-made premium cigar with Connecticut wrapper.",
        price: 19.99,
        origin: "Dominican Republic",
        wrapper: "Connecticut",
        category: "Premium Cigars"
      },
      // Add more products...
    ]
  }
};

export default function Products() {
  const [selectedCategory, setSelectedCategory] = React.useState('All');
  const [selectedSubcategory, setSelectedSubcategory] = React.useState('All');

  return (
    <>
      <Helmet>
        <title>Shop Premium Vapes, THCA & Smoking Accessories | Sunshine Smoke Shop</title>
        <meta name="description" content="Browse our selection of premium vapes, THCA products, edibles, and smoking accessories. Quality products with fast delivery in Orlando & Kissimmee." />
        <meta name="keywords" content="vape shop Orlando, THCA products Kissimmee, smoke shop near Disney World, CBD store International Drive, Delta-8 Universal Studios" />
      </Helmet>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Shop Our Products</h1>
          <p className="text-xl text-gray-600">
            Premium vapes, THCA products, and smoking accessories
          </p>
        </div>

        {/* Category Navigation */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Categories</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {Object.entries(categories).map(([category, data], index) => (
              <motion.div
                key={category}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
              >
                <h3 className="text-lg font-bold text-gray-900 mb-3">{category}</h3>
                <ul className="space-y-2">
                  {data.subcategories.map((sub) => (
                    <li key={sub}>
                      <Link
                        to={`/products/${sub.toLowerCase().replace(/\s+/g, '-')}`}
                        className="text-gray-600 hover:text-primary-600 transition-colors"
                      >
                        {sub}
                      </Link>
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Special Sections */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {[
            {
              title: "New Arrivals",
              description: "Latest product drops & exclusives",
              link: "/products/new-arrivals",
              icon: "🆕"
            },
            {
              title: "Best Sellers",
              description: "Most popular products our customers love",
              link: "/products/best-sellers",
              icon: "⭐"
            },
            {
              title: "Deals & Bundles",
              description: "Special promotions & combo deals",
              link: "/products/deals",
              icon: "🎁"
            }
          ].map((section, index) => (
            <motion.div
              key={section.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-gradient-to-r from-herb-dark to-herb text-white rounded-lg p-6"
            >
              <div className="text-3xl mb-3">{section.icon}</div>
              <h3 className="text-xl font-bold mb-2">{section.title}</h3>
              <p className="text-herb-light mb-4">{section.description}</p>
              <Link
                to={section.link}
                className="inline-block bg-white text-herb-dark px-4 py-2 rounded-lg hover:bg-gray-100 transition-colors"
              >
                Shop Now
              </Link>
            </motion.div>
          ))}
        </div>

        {/* SEO Content */}
        <div className="bg-white rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Why Choose Sunshine Smoke?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Quality Products</h3>
              <ul className="space-y-2 text-gray-600">
                <li>✓ Lab-tested for purity and potency</li>
                <li>✓ Premium brands and exclusive products</li>
                <li>✓ Carefully curated selection</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Excellent Service</h3>
              <ul className="space-y-2 text-gray-600">
                <li>✓ Fast delivery in Orlando & Kissimmee</li>
                <li>✓ Knowledgeable staff</li>
                <li>✓ Multiple convenient locations</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}