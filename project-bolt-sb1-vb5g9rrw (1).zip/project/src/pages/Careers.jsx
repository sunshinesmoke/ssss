import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function Careers() {
  const [resume, setResume] = React.useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!resume) {
      toast.error('Please upload your resume');
      return;
    }

    // Create form data for email
    const formData = {
      position: e.target.position.value,
      name: e.target.name.value,
      email: e.target.email.value,
      phone: e.target.phone.value,
      experience: e.target.experience.value,
      resume: resume.name
    };

    // Send application to info@sunshinesmoke.com
    window.location.href = `mailto:info@sunshinesmoke.com?subject=Job Application - ${formData.position}&body=${encodeURIComponent(
      `Position: ${formData.position}
Name: ${formData.name}
Email: ${formData.email}
Phone: ${formData.phone}
Experience: ${formData.experience}

Resume attached: ${formData.resume}

Note: Due to email limitations, please respond to this email to receive the resume file.`
    )}`;

    toast.success('Application submitted successfully!');
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      // Check file type
      const validTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
      if (!validTypes.includes(file.type)) {
        toast.error('Please upload a PDF or Word document');
        e.target.value = '';
        return;
      }

      // Check file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast.error('File size must be less than 5MB');
        e.target.value = '';
        return;
      }

      setResume(file);
      toast.success('Resume uploaded successfully!');
    }
  };

  return (
    <>
      <Helmet>
        <title>Join Our Team | Careers at Sunshine Smoke Shop</title>
        <meta name="description" content="Join the Sunshine Smoke team! We're hiring passionate individuals for our Orlando & Kissimmee locations. Competitive pay, flexible scheduling, and growth opportunities." />
      </Helmet>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-lg shadow-lg overflow-hidden"
        >
          {/* Hero Section */}
          <div className="bg-gradient-to-r from-primary-600 to-secondary-500 px-6 py-12 text-center text-white">
            <h1 className="text-4xl font-bold mb-4">Join the Sunshine Smoke Team!</h1>
            <p className="text-xl text-primary-100">
              We're more than just a smoke shop—we're a community.
            </p>
          </div>

          {/* Main Content */}
          <div className="p-8">
            <section className="mb-12">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Why Work With Us?</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {[
                  { title: 'Competitive Pay', desc: 'We value our employees and offer great wages.' },
                  { title: 'Employee Discounts', desc: 'Get exclusive discounts on our premium products.' },
                  { title: 'Flexible Scheduling', desc: 'We offer part-time and full-time positions.' },
                  { title: 'Growth Opportunities', desc: 'Advance your career in the booming smoke shop industry.' },
                  { title: 'Fun & Friendly Atmosphere', desc: 'Work with a team that feels like family.' }
                ].map((benefit, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-gray-50 p-6 rounded-lg"
                  >
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">✔ {benefit.title}</h3>
                    <p className="text-gray-600">{benefit.desc}</p>
                  </motion.div>
                ))}
              </div>
            </section>

            <section className="mb-12">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Available Positions</h2>
              <div className="space-y-6">
                {[
                  { role: 'Sales Associate', desc: 'Help customers find the best THCA, vapes, and accessories.' },
                  { role: 'Store Manager', desc: 'Lead a team and manage daily operations.' },
                  { role: 'Inventory Specialist', desc: 'Keep our stock organized and up to date.' },
                  { role: 'Delivery Driver', desc: 'Provide fast and reliable THCA delivery in Orlando & Kissimmee.' }
                ].map((position, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow"
                  >
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">🔹 {position.role}</h3>
                    <p className="text-gray-600">{position.desc}</p>
                  </motion.div>
                ))}
              </div>
            </section>

            <section className="mb-12">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Requirements</h2>
              <div className="bg-white border border-gray-200 rounded-lg p-6">
                <ul className="space-y-3">
                  <li className="flex items-center text-gray-700">
                    <span className="text-green-500 mr-2">✅</span>
                    Must be 18+ years old
                  </li>
                  <li className="flex items-center text-gray-700">
                    <span className="text-green-500 mr-2">✅</span>
                    Friendly and customer-focused attitude
                  </li>
                  <li className="flex items-center text-gray-700">
                    <span className="text-green-500 mr-2">✅</span>
                    Knowledge of smoke shop products (or willingness to learn!)
                  </li>
                  <li className="flex items-center text-gray-700">
                    <span className="text-green-500 mr-2">✅</span>
                    Ability to work in a fast-paced retail environment
                  </li>
                  <li className="flex items-center text-gray-700">
                    <span className="text-green-500 mr-2">✅</span>
                    Must have reliable transportation (for delivery positions)
                  </li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Apply Now</h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="position" className="block text-sm font-medium text-gray-700">
                    Position
                  </label>
                  <select
                    id="position"
                    name="position"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                  >
                    <option value="">Select a position</option>
                    <option value="Sales Associate">Sales Associate</option>
                    <option value="Store Manager">Store Manager</option>
                    <option value="Inventory Specialist">Inventory Specialist</option>
                    <option value="Delivery Driver">Delivery Driver</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                    Full Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                  />
                </div>

                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                    Phone
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                  />
                </div>

                <div>
                  <label htmlFor="experience" className="block text-sm font-medium text-gray-700">
                    Relevant Experience
                  </label>
                  <textarea
                    id="experience"
                    name="experience"
                    rows={4}
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                  ></textarea>
                </div>

                <div>
                  <label htmlFor="resume" className="block text-sm font-medium text-gray-700">
                    Resume (PDF or Word document, max 5MB)
                  </label>
                  <div className="mt-1 flex items-center">
                    <input
                      type="file"
                      id="resume"
                      name="resume"
                      accept=".pdf,.doc,.docx"
                      required
                      onChange={handleFileChange}
                      className="block w-full text-sm text-gray-500
                        file:mr-4 file:py-2 file:px-4
                        file:rounded-md file:border-0
                        file:text-sm file:font-semibold
                        file:bg-primary-50 file:text-primary-700
                        hover:file:bg-primary-100
                        focus:outline-none focus:ring-2 focus:ring-primary-500"
                    />
                  </div>
                  {resume && (
                    <p className="mt-2 text-sm text-green-600">
                      ✓ {resume.name} uploaded successfully
                    </p>
                  )}
                  <p className="mt-2 text-xs text-gray-500">
                    Accepted formats: PDF, DOC, DOCX
                  </p>
                </div>

                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-primary-600 to-secondary-500 text-white py-3 px-4 rounded-md hover:from-primary-700 hover:to-secondary-600 transition-colors font-medium"
                >
                  Submit Application
                </button>
              </form>
            </section>
          </div>
        </motion.div>
      </div>
    </>
  );
}