import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';
import Cookies from 'js-cookie';

// Import translations
import enTranslations from './locales/en.json';
import esTranslations from './locales/es.json';
import frTranslations from './locales/fr.json';
import ptTranslations from './locales/pt.json';
import ruTranslations from './locales/ru.json';
import zhTranslations from './locales/zh.json';
import jaTranslations from './locales/ja.json';
import koTranslations from './locales/ko.json';
import deTranslations from './locales/de.json';
import itTranslations from './locales/it.json';

const resources = {
  en: { translation: enTranslations },
  es: { translation: esTranslations },
  fr: { translation: frTranslations },
  pt: { translation: ptTranslations },
  ru: { translation: ruTranslations },
  zh: { translation: zhTranslations },
  ja: { translation: jaTranslations },
  ko: { translation: koTranslations },
  de: { translation: deTranslations },
  it: { translation: itTranslations }
};

// Initialize i18n
i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'en',
    supportedLngs: Object.keys(resources),
    detection: {
      order: ['querystring', 'cookie', 'localStorage', 'navigator', 'htmlTag'],
      lookupQuerystring: 'lang',
      lookupCookie: 'i18next',
      lookupLocalStorage: 'i18nextLng',
      caches: ['localStorage', 'cookie'],
      cookieMinutes: 60 * 24 * 365, // 1 year
      cookieDomain: window.location.hostname
    },
    interpolation: {
      escapeValue: false
    }
  });

// Set initial language based on browser/cookie
try {
  const savedLang = Cookies.get('i18next');
  const browserLang = navigator.language?.split('-')[0] || 'en';
  const initialLang = savedLang || browserLang;

  if (Object.keys(resources).includes(initialLang)) {
    i18n.changeLanguage(initialLang);
    document.documentElement.lang = initialLang;
  } else {
    i18n.changeLanguage('en');
    document.documentElement.lang = 'en';
  }
} catch (error) {
  console.warn('Error setting initial language:', error);
  i18n.changeLanguage('en');
  document.documentElement.lang = 'en';
}

// Update HTML lang attribute when language changes
i18n.on('languageChanged', (lng) => {
  document.documentElement.lang = lng;
});

export default i18n;